package mx.stackcloud.cm.repository;

import mx.stackcloud.cm.model.CaseDetail;

import java.util.Optional;

public interface CaseDetailRepository {
    Optional<CaseDetail> findById(int caseId);
}
