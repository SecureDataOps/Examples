package mx.stackcloud.cm.repository;

import mx.stackcloud.cm.model.Search;

import java.util.List;
import java.util.Optional;

public interface SearchRepository {

    /**
     * Retrieves all search records for a given case, ordered for tree reconstruction.
     * Results are ordered by NIVEL ASC, ID ASC so that parents always precede their children.
     *
     * @param caseId numeric case identifier
     * @return ordered list of {@link Search} records; empty if none exist
     */
    List<Search> findByCaseId(long caseId);

    /**
     * Inserts a new search record into CM_FORM_BUSQUEDA and returns the generated ID.
     *
     * @param caseId       case identifier (FK → CM_BITACORA_ACTUAL)
     * @param formId       active form version identifier (FK → CM_FORM_CAPTURA_HISTORICO)
     * @param parentId     parent search ID for chained searches; {@code null} for the initial search (nivel 1)
     * @param nivel        depth level in the search tree — 1 for the initial search
     * @param jsonSnapshot exact JSON from the active form, stored as CLOB; must not be null or blank
     * @param status       result status — {@code "SUCCESS"} or {@code "ERROR"}
     * @param userId       ID of the user that triggered the operation
     * @return generated {@code ID} of the inserted row, or {@code -1} on failure
     * @throws RuntimeException wrapping the underlying {@link java.sql.SQLException} on persistence failure
     */
    long saveBusqueda(
            long caseId,
            long formId,
            Long parentId,
            int nivel,
            String jsonSnapshot,
            String status,
            int userId
    );

    /**
     * Retrieves a search record by its primary key.
     *
     * @param id primary key of CM_FORM_BUSQUEDA
     * @return the matching {@link Search}, or {@link Optional#empty()} if not found
     */
    Optional<Search> findById(long id);
}
