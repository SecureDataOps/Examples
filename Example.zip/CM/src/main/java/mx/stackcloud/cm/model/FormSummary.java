package mx.stackcloud.cm.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Human-readable summary of a form snapshot stored in CM_FORM_CAPTURA_HISTORICO.
 * Derived on demand from the JSON field — never persisted.
 *
 * <p>Built exclusively by
 * {@link mx.stackcloud.cm.common.util.FormSummaryBuilder#buildFromJson(String)}.
 */
@Getter
@Setter
@NoArgsConstructor
public class FormSummary implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    /** One entry per {@link ReportBlock} found in the parsed JSON. */
    private List<BlockSummary> bloques = new ArrayList<>();

    /** True when at least one block has {@code deviceHistory = true}. */
    private boolean deviceHistory;

    /** True when at least one block has {@code suscriberHistory = true}. */
    private boolean suscriberHistory;

    /**
     * Returns {@code true} when the summary contains no blocks
     * (empty form or unparseable JSON snapshot).
     */
    public boolean isEmpty() {
        return bloques == null || bloques.isEmpty();
    }
}
