package mx.stackcloud.cm.repository;

import java.sql.Connection;
import java.util.Optional;

/**
 * Repositorio para el snapshot del estado actual del caso en DEV_CASOS.
 *
 * Contiene exactamente un registro por caso. Se actualiza en cada transición.
 *
 * Cada método existe en dos variantes:
 * - Sin Connection: abre su propia conexión (uso general).
 * - Con Connection: reutiliza la conexión provista externamente (uso transaccional).
 *   En la variante con Connection el repositorio NO cierra ni hace commit/rollback.
 */
public interface BitacoraActualRepository {

    /**
     * Obtiene el ID del estado actual del caso usando una conexión propia.
     *
     * @param caseId identificador del caso (id_caso en DEV_CASOS)
     * @return Optional con el ID de estado actual, vacío si el caso no existe
     */
    Optional<Integer> findCurrentStatus(long caseId);

    /**
     * Obtiene el ID del estado actual del caso reutilizando una conexión externa.
     *
     * <p>Usar en contextos transaccionales. El llamador es responsable de gestionar
     * el ciclo de vida de {@code conn} (commit, rollback, close).
     *
     * @param conn   conexión activa con autoCommit=false
     * @param caseId identificador del caso
     * @return Optional con el ID de estado actual, vacío si el caso no existe
     */
    Optional<Integer> findCurrentStatus(Connection conn, long caseId);

    /**
     * Actualiza el estado actual del caso solo si coincide con {@code expectedStatusId}.
     * Abre su propia conexión.
     *
     * <p>SQL ejecutado:
     * <pre>{@code
     * UPDATE APPS.DEV_CASOS
     * SET    id_estatus = ?, FECHA_ESTATUS = SYSDATE, id_usuario_creacion = ?
     * WHERE  id_caso = ? AND id_estatus = ?
     * }</pre>
     *
     * @param caseId           identificador del caso
     * @param expectedStatusId estado que debe existir actualmente en BD (pre-condición)
     * @param newStatusId      nuevo estado a aplicar
     * @param userId           ID del usuario que realiza el cambio
     * @return filas afectadas: {@code 1} en éxito, {@code 0} si hubo cambio concurrente
     */
    int updateCurrentStatus(long caseId, int expectedStatusId, int newStatusId, long userId);

    /**
     * Actualiza el estado actual del caso reutilizando una conexión externa.
     *
     * <p>Usar en contextos transaccionales. El llamador controla commit y rollback.
     * La cláusula WHERE compuesta garantiza idempotencia y seguridad ante concurrencia.
     *
     * @param conn             conexión activa con autoCommit=false
     * @param caseId           identificador del caso (id_caso en DEV_CASOS)
     * @param expectedStatusId estado que debe existir actualmente en BD (pre-condición)
     * @param newStatusId      nuevo estado a aplicar
     * @param userId           ID del usuario que realiza el cambio
     * @return filas afectadas: {@code 1} en éxito, {@code 0} si hubo cambio concurrente
     */
    int updateCurrentStatus(Connection conn, long caseId, int expectedStatusId, int newStatusId, long userId);
}
