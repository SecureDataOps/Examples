package mx.stackcloud.cm.service;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;
import jakarta.json.JsonValue;
import mx.stackcloud.cm.common.exception.CaseSaveException;
import mx.stackcloud.cm.common.exception.InvalidStatusTransitionException;
import mx.stackcloud.cm.model.AllUsageDirection;
import mx.stackcloud.cm.model.AllUsageReportType;
import mx.stackcloud.cm.model.CaptureForm;
import mx.stackcloud.cm.model.CaseDetail;
import mx.stackcloud.cm.model.CaseEvent;
import mx.stackcloud.cm.model.CDRsReportType;
import mx.stackcloud.cm.model.CDRsRoamingReportType;
import mx.stackcloud.cm.model.ChecklistGroup;
import mx.stackcloud.cm.model.ChecklistItem;
import mx.stackcloud.cm.model.ChecklistItemType;
import mx.stackcloud.cm.model.CoverageType;
import mx.stackcloud.cm.model.CriteriaType;
import mx.stackcloud.cm.model.HistoryReportType;
import mx.stackcloud.cm.model.ManualResult;
import mx.stackcloud.cm.model.MiddlewareJob;
import mx.stackcloud.cm.model.OnDemandReportType;
import mx.stackcloud.cm.model.Search;
import mx.stackcloud.cm.model.StandardReportType;
import mx.stackcloud.cm.model.Status;
import mx.stackcloud.cm.model.TargetStatus;
import mx.stackcloud.cm.repository.AddendumRepository;
import mx.stackcloud.cm.repository.BitacoraActualRepository;
import mx.stackcloud.cm.repository.BitacoraRepository;
import mx.stackcloud.cm.repository.CaseCaptureRepository;
import mx.stackcloud.cm.repository.CaseDetailRepository;
import mx.stackcloud.cm.repository.MiddlewareRepository;
import mx.stackcloud.cm.repository.SearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mx.stackcloud.cm.common.tx.DataSourceConnectionProvider;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;


/**
 * Servicio de aplicación encargado de gestionar el ciclo de vida de los casos.
 *
 * <p>Esta clase centraliza la lógica de negocio relacionada con:
 * <ul>
 *   <li>Transiciones de estado mediante una máquina de estados</li>
 *   <li>Consistencia transaccional entre estado actual y bitácora histórica</li>
 *   <li>Validaciones de negocio para guardado de casos</li>
 *   <li>Ejecución y persistencia de búsquedas</li>
 *   <li>Versionamiento de formularios</li>
 * </ul>
 *
 * <p>Las transiciones de estado se ejecutan de forma atómica, garantizando que:
 * <ul>
 *   <li>No exista cambio de estado sin registro en bitácora</li>
 *   <li>No exista registro en bitácora sin cambio de estado</li>
 * </ul>
 *
 * <p>El servicio está diseñado para ser:
 * <ul>
 *   <li>Idempotente en operaciones críticas</li>
 *   <li>Seguro ante concurrencia</li>
 *   <li>Independiente de sistemas externos</li>
 * </ul>
 */
@Named
@ApplicationScoped
public class CaseService {

    private static final Logger log = LoggerFactory.getLogger(CaseService.class);

    private static final String TIPO_SHERLOCK  = "SHERLOCK";
    private static final String STATUS_SUCCESS = "SUCCESS";
    private static final String STATUS_ERROR   = "ERROR";
    private static final int    MAX_SEARCH_DEPTH = 10;
    private record Transition(Status from, Status to) {}

    @Inject
    CaseCaptureRepository caseCaptureRepository;

    @Inject
    CaseDetailRepository caseDetailRepository;

    @Inject
    AddendumRepository addendumRepository;

    @Inject
    SearchRepository searchRepository;

    @Inject
    BitacoraRepository bitacoraRepository;

    @Inject
    BitacoraActualRepository bitacoraActualRepository;

    @Inject
    DataSourceConnectionProvider dataSourceConnectionProvider;

    @Inject
    MiddlewareRepository middlewareRepository;

    /**
     * Abre un caso si su estado actual es {@link Status#NEW}.
     *
     * <p>Si el estado no es {@code NEW}, la operación no realiza cambios
     * (comportamiento idempotente).
     *
     * @param caseId identificador del caso
     * @param userId identificador del usuario que ejecuta la acción
     */
    public void openCaseIfNeeded(long caseId, long userId) {

        Status current = getCurrentStatus(caseId);

        if (current != Status.NEW) {
            return; // idempotente real
        }

        changeStatusTransactional(
                caseId,
                Status.NEW,
                Status.READ,
                CaseEvent.OPEN_CASE_VIEW,
                userId
        );
    }

    /**
     * Ejecuta una transición de estado dentro de una única transacción JDBC.
     *
     * <p>Garantiza atomicidad entre la actualización del estado actual y el registro
     * en la bitácora histórica.
     *
     * <p>Flujo interno:
     * <ol>
     *   <li>Obtiene conexión y desactiva autoCommit</li>
     *   <li>Lee el estado actual</li>
     *   <li>Valida existencia del caso</li>
     *   <li>Aplica reglas de negocio (ej. PENDING)</li>
     *   <li>Valida idempotencia</li>
     *   <li>Valida transición de estado</li>
     *   <li>Valida evento</li>
     *   <li>Actualiza estado actual</li>
     *   <li>Inserta registro en bitácora</li>
     *   <li>Realiza commit</li>
     * </ol>
     *
     * @param caseId identificador del caso
     * @param expectedStatus estado esperado en base de datos
     * @param newStatus nuevo estado a aplicar
     * @param event evento que origina la transición
     * @param userId identificador del usuario
     * @throws InvalidStatusTransitionException si la transición no es válida
     * @throws RuntimeException si ocurre un error en la transacción
     */
    public void changeStatusTransactional(long caseId,
                                          Status expectedStatus,
                                          Status newStatus,
                                          CaseEvent event,
                                          long userId) {

        Connection conn = null;

        try {
            conn = dataSourceConnectionProvider.getConnection();
            conn.setAutoCommit(false);

            // 1. Leer estado actual
            Optional<Integer> currentOpt = bitacoraActualRepository.findCurrentStatus(conn, caseId);

            if (currentOpt.isEmpty()) {
                log.warn("changeStatusTransactional: sin registro en DEV_CASOS — caseId={}", caseId);
                conn.rollback();
                return;
            }

            Status current = Status.fromId(currentOpt.get());

            // =========================
            // 🔥 2. Blindaje de PENDING
            // =========================
            if (current == Status.PENDING && event != CaseEvent.RESUME_FROM_PENDING) {
                log.error("Invalid transition from PENDING without RESUME event — caseId={} event={}", caseId, event);
                conn.rollback();
                throw new IllegalStateException(
                        "Transition from PENDING requires RESUME_FROM_PENDING event. caseId=" + caseId
                );
            }

            // =========================
            // 3. Idempotencia
            // =========================
            if (current != expectedStatus) {
                log.info("changeStatusTransactional: salida idempotente — caseId={} current={} expected={} event={}",
                        caseId, current, expectedStatus, event);
                conn.rollback();
                return;
            }

            // =========================
            // 4. Validar transición (estado)
            // =========================
            if (event != CaseEvent.RESUME_FROM_PENDING) {

                if (!current.canTransitionTo(newStatus)) {
                    log.error("changeStatusTransactional: transicion invalida — caseId={} {}→{} event={}",
                            caseId, current, newStatus, event);
                    conn.rollback();
                    throw new InvalidStatusTransitionException(current, newStatus);
                }

            }

            // =========================
            // 🔥 5. Validar evento
            // =========================
            validateEventMatchesTransition(current, newStatus, event);

            // =========================
            // 6. UPDATE (fuente de verdad)
            // =========================
            int updated = bitacoraActualRepository.updateCurrentStatus(
                    conn,
                    caseId,
                    expectedStatus.getId(),
                    newStatus.getId(),
                    userId
            );

            // =========================
            // 7. Concurrencia
            // =========================
            if (updated == 0) {
                log.warn("changeStatusTransactional: concurrencia detectada — caseId={} {}→{}",
                        caseId, expectedStatus, newStatus);
                conn.rollback();
                return;
            }

            // =========================
            // 8. INSERT histórico
            // =========================
            bitacoraRepository.insert(
                    conn,
                    caseId,
                    newStatus.getId(),
                    userId,
                    event.name()
            );

            conn.commit();

            log.info("changeStatusTransactional: COMMIT OK — caseId={} {}→{} event={} userId={}",
                    caseId, current, newStatus, event, userId);

        } catch (InvalidStatusTransitionException e) {
            throw e;

        } catch (Exception e) {

            log.error("changeStatusTransactional: ERROR — caseId={} {}→{} event={}",
                    caseId, expectedStatus, newStatus, event, e);

            safeRollback(conn, caseId);

            throw new RuntimeException(
                    "Error en transicion de estado."
                            + " caseId=" + caseId
                            + " expected=" + expectedStatus.name()
                            + " new=" + newStatus.name()
                            + " event=" + event.name(),
                    e
            );

        } finally {
            safeClose(conn, caseId);
        }
    }

    /**
     * Valida que un evento permita una transición entre estados.
     *
     * @param current estado actual
     * @param next estado destino
     * @param event evento asociado
     * @throws IllegalStateException si la transición no es válida para el evento
     */
    private void validateEventMatchesTransition(Status current,
                                                Status next,
                                                CaseEvent event) {

        List<Transition> allowed = getAllowedTransitionsForEvent(event);

        if (allowed == null) {
            // Evento no restringido → permitir
            return;
        }

        boolean valid = allowed.stream()
                .anyMatch(t -> t.from == current && t.to == next);

        if (!valid) {
            throw new IllegalStateException(
                    "Invalid event transition: event=" + event
                            + " does not allow " + current + " → " + next
            );
        }
    }

    /**
     * Obtiene las transiciones permitidas para un evento específico.
     *
     * @param event evento de dominio
     * @return lista de transiciones válidas o {@code null} si no aplica restricción
     */
    private List<Transition> getAllowedTransitionsForEvent(CaseEvent event) {

        return switch (event) {

            case OPEN_CASE_VIEW -> List.of(
                    new Transition(Status.NEW, Status.READ)
            );

            case SAVE_FIRST_FORM -> List.of(
                    new Transition(Status.READ, Status.CAPTURE)
            );

            case SAVE_CASE -> List.of(
                    new Transition(Status.CAPTURE, Status.IN_PROGRESS)
            );

            case MARK_PENDING -> List.of(
                    new Transition(Status.CAPTURE, Status.PENDING),
                    new Transition(Status.IN_PROGRESS, Status.PENDING),
                    new Transition(Status.READY, Status.PENDING)
            );

            case CANCEL_CASE -> List.of(
                    new Transition(Status.NEW, Status.CANCELED),
                    new Transition(Status.READ, Status.CANCELED),
                    new Transition(Status.CAPTURE, Status.CANCELED),
                    new Transition(Status.IN_PROGRESS, Status.CANCELED),
                    new Transition(Status.READY, Status.CANCELED),
                    new Transition(Status.RESOLVED, Status.CANCELED),
                    new Transition(Status.REOPENED, Status.CANCELED)
            );

            case READY_CASE -> List.of(
                    new Transition(Status.IN_PROGRESS, Status.READY)
            );

            case RESUME_FROM_PENDING -> null; // dinámica (historia)

            default -> null;
        };
    }



    /**
     * Ejecuta rollback de la transacción de forma segura.
     *
     * @param conn conexión JDBC
     * @param caseId identificador del caso
     */
    private void safeRollback(Connection conn, long caseId) {
        if (conn == null) return;
        try {
            conn.rollback();
        } catch (SQLException ex) {
            log.error("changeStatusTransactional: ROLLBACK FAILED — caseId={} causa={}", caseId, ex.getMessage());
        }
    }

    /**
     * Cierra la conexión JDBC restaurando el estado de autoCommit.
     *
     * @param conn conexión JDBC
     * @param caseId identificador del caso
     */
    private void safeClose(Connection conn, long caseId) {
        if (conn == null) return;
        try {
            conn.setAutoCommit(true);
        } catch (Exception ex) {
            log.error("changeStatusTransactional: setAutoCommit FAILED — caseId={} causa={}", caseId, ex.getMessage());
        }
        try {
            conn.close();
        } catch (Exception ex) {
            log.error("changeStatusTransactional: close FAILED — caseId={} causa={}", caseId, ex.getMessage());
        }
    }

    // ── Estado actual ─────────────────────────────────────────────────────────

    /**
     * Obtiene el estado actual del caso.
     *
     * @param caseId identificador del caso
     * @return estado actual
     * @throws IllegalStateException si no existe estado para el caso
     */
    private Status getCurrentStatus(long caseId) {
        return bitacoraActualRepository.findCurrentStatus(caseId)
                .map(Status::fromId)
                .orElseThrow(() -> new IllegalStateException(
                        "No status found for caseId=" + caseId));
    }

    /**
     * Cancela un caso si no se encuentra en un estado terminal.
     *
     * <p>Si el caso ya está cancelado o cerrado, la operación es idempotente.
     *
     * @param caseId identificador del caso
     * @param userId identificador del usuario
     */
    public void cancelCase(long caseId, long userId) {
        Status current = getCurrentStatus(caseId);

        if (current == Status.CANCELED || current == Status.CLOSED) {
            log.info("cancelCase: caso ya en estado terminal — caseId={} status={}", caseId, current);
            return;
        }

        changeStatusTransactional(caseId, current, Status.CANCELED, CaseEvent.CANCEL_CASE, userId);
    }

    /**
     * Marca un caso como pendiente.
     *
     * <p>No aplica si el caso está en estado terminal.
     *
     * @param caseId identificador del caso
     * @param userId identificador del usuario
     */
    public void markPending(long caseId, long userId) {
        Status current = getCurrentStatus(caseId);

        if (current == Status.CANCELED || current == Status.CLOSED) {
            log.info("markPending: caso en estado terminal — caseId={} status={}", caseId, current);
            return;
        }

        changeStatusTransactional(caseId, current, Status.PENDING, CaseEvent.MARK_PENDING, userId);
    }

    /**
     * Reanuda un caso desde estado {@link Status#PENDING}.
     *
     * <p>El estado previo se obtiene desde la bitácora histórica.
     *
     * @param caseId identificador del caso
     * @param userId identificador del usuario
     * @throws IllegalStateException si no existe estado previo
     */
    public void resumeFromPending(long caseId, long userId) {
        Status current = getCurrentStatus(caseId);

        if (current != Status.PENDING) {
            log.info("resumeFromPending: caso no está en PENDING — caseId={} status={}", caseId, current);
            return;
        }

        Status previous = bitacoraRepository.findPreviousStatusBeforePending(caseId, Status.PENDING.getId())
                .map(Status::fromId)
                .orElseThrow(() -> new IllegalStateException(
                        "No previous state found for caseId=" + caseId));

        changeStatusTransactional(caseId, Status.PENDING, previous, CaseEvent.RESUME_FROM_PENDING, userId);
    }

    // ── Guardar Caso ──────────────────────────────────────────────────────────

    /**
     * Ejecuta el flujo completo de guardado de un caso.
     *
     * <p>Incluye:
     * <ul>
     *   <li>Validación de complemento</li>
     *   <li>Validación de formulario activo</li>
     *   <li>Transición de estado</li>
     *   <li>Ejecución de búsqueda inicial</li>
     * </ul>
     *
     * @param caseId  identificador del caso
     * @param idToken token del caso (id_token de DEV_SOLICITUD)
     * @param userId  identificador del usuario
     * @throws CaseSaveException si falla alguna validación
     * @throws InvalidStatusTransitionException si la transición es inválida
     */
    public void saveCase(long caseId, String idToken, long userId) throws CaseSaveException {
        validateComplemento(idToken);
        CaptureForm form = validateActiveForm(caseId);
        changeStatusTransactional(caseId, Status.CAPTURE, Status.IN_PROGRESS, CaseEvent.SAVE_CASE, userId);
        try {
            dispatchSearch(caseId, form, userId);
        } catch (Exception e) {
            log.error("Error executing search for case {}", caseId, e);
        }
    }

    /**
     * Valida que exista un complemento asociado al token del caso.
     *
     * @param idToken token del caso (id_token de DEV_SOLICITUD)
     * @throws CaseSaveException si no existe complemento
     */
    private void validateComplemento(String idToken) throws CaseSaveException {
        if (idToken == null || idToken.isBlank() || "—".equals(idToken)) {
            throw new CaseSaveException(
                    "El token del caso no está disponible. No es posible validar el complemento.");
        }
        if (addendumRepository.findByFolio(idToken).isEmpty()) {
            throw new CaseSaveException(
                    "Debe completar el Complemento de la solicitud antes de guardar el caso.");
        }
    }

    /**
     * Valida que exista un formulario activo con contenido válido.
     *
     * @param caseId identificador del caso
     * @return formulario activo
     * @throws CaseSaveException si no existe o es inválido
     */
    private CaptureForm validateActiveForm(long caseId) throws CaseSaveException {
        CaptureForm form = caseCaptureRepository.findActiveForm((int) caseId)
                .orElseThrow(() -> new CaseSaveException(
                        "Debe capturar y guardar el formulario de parámetros antes de guardar el caso."));

        if (form.getJsonForm() == null || form.getJsonForm().isBlank()) {
            throw new CaseSaveException(
                    "El formulario activo no contiene datos válidos. Capture el formulario nuevamente.");
        }

        return form;
    }

    /**
     * Determina si se debe ejecutar una búsqueda inicial.
     *
     * @param caseId identificador del caso
     * @param form formulario activo
     * @param userId identificador del usuario
     */
    private void dispatchSearch(long caseId, CaptureForm form, long userId) {
        log.debug("dispatchSearch: caseId={} formId={}", caseId, form.getId());

        String tipo = form.getTipoFormulario();

        // ── Branch 1: tipo desconocido o distinto a SHERLOCK ─────────────────
        if (tipo == null || !TIPO_SHERLOCK.equalsIgnoreCase(tipo)) {
            log.info("Case {} saved without search. TipoFormulario={}", caseId, tipo);
            return;
        }

        // ── Branch 2: SHERLOCK sin criterios reales en el formulario ─────────
        if (!form.requiresAutomaticSearch()) {
            log.info("Case {} saved. SHERLOCK without search criteria -> skipping search", caseId);
            return;
        }

        // ── Branch 3: SHERLOCK con criterios → ejecutar búsqueda ─────────────
        log.info("Case {} saved. Triggering initial search.", caseId);
        executeInitialSearch(caseId, form, userId);
    }

    /**
     * Ejecuta y persiste la búsqueda inicial del caso.
     *
     * @param caseId identificador del caso
     * @param form formulario activo
     * @param userId identificador del usuario
     */
    private void executeInitialSearch(long caseId, CaptureForm form, long userId) {

        long formId = form.getId();
        String json = form.getJsonForm();

        if (formId <= 0) {
            throw new IllegalStateException("Invalid form ID for search execution");
        }

        if (json == null || json.isBlank()) {
            log.error("executeInitialSearch aborted — jsonForm is null or blank for formId={}", formId);
            throw new IllegalArgumentException(
                    "Form JSON is null or empty for search snapshot. formId=" + formId);
        }

        log.debug("Saving search snapshot: caseId={}, formId={}, nivel=1", caseId, formId);

        String searchStatus;
        try {
            // TODO: integrar llamada a sistema externo de búsqueda
            searchStatus = STATUS_SUCCESS;
        } catch (Exception e) {
            log.error("Error during external search execution for case {}", caseId, e);
            searchStatus = STATUS_ERROR;
        }

        searchRepository.saveBusqueda(caseId, formId, null, 1, json, searchStatus, (int) userId);

        log.info("Initial search stored for case {} form {}", caseId, formId);
    }

    /**
     * Ejecuta una búsqueda encadenada basada en una búsqueda previa.
     *
     * @param caseId identificador del caso
     * @param parentBusquedaId identificador de la búsqueda padre
     * @param form formulario activo
     * @param userId identificador del usuario
     */
    public void executeNextSearch(long caseId, long parentBusquedaId, CaptureForm form, long userId) {

        long formId = form.getId();
        if (formId <= 0) {
            throw new IllegalStateException("Invalid form ID for chained search");
        }

        String json = form.getJsonForm();
        if (json == null || json.isBlank()) {
            log.warn("executeNextSearch aborted — jsonForm is null or blank for formId={}", formId);
            return;
        }

        Search parent = searchRepository.findById(parentBusquedaId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Parent search not found: busquedaId=" + parentBusquedaId));

        if (parent.getCaseId() != caseId) {
            throw new IllegalArgumentException(String.format(
                    "Parent search %d belongs to case %d, not case %d — cross-case chaining rejected",
                    parentBusquedaId, parent.getCaseId(), caseId));
        }

        if (parent.getNivel() <= 0) {
            throw new IllegalStateException("Invalid parent nivel: " + parent.getNivel());
        }

        int nivel = parent.getNivel() + 1;

        if (nivel > MAX_SEARCH_DEPTH) {
            log.warn("Max search depth ({}) reached for case {} — skipping chained search",
                    MAX_SEARCH_DEPTH, caseId);
            return;
        }

        log.info("Executing chained search: caseId={}, parentId={}, nivel={}",
                caseId, parentBusquedaId, nivel);

        // TODO: integrar llamada a sistema externo de búsqueda
        String searchStatus = STATUS_SUCCESS;

        long newId = searchRepository.saveBusqueda(
                caseId, formId, parentBusquedaId, nivel, json, searchStatus, (int) userId
        );

        if (newId <= 0) {
            log.warn("Search insert did not return generated ID for case {}", caseId);
        }

        log.info("Chained search stored: busquedaId={} caseId={} parentId={} nivel={}",
                newId, caseId, parentBusquedaId, nivel);
    }

    /**
     * Obtiene todas las búsquedas asociadas a un caso.
     *
     * @param caseId identificador del caso
     * @return lista de búsquedas
     */
    public List<Search> findBusquedasByCaseId(long caseId) {
        return searchRepository.findByCaseId(caseId);
    }

    /**
     * Guarda una nueva versión del formulario.
     *
     * <p>Si es la primera versión, dispara la transición READ → CAPTURE.
     *
     * @param json contenido del formulario
     * @param tipoFormulario tipo de formulario
     * @param userId identificador del usuario
     * @param caseId identificador del caso
     * @return identificador generado o -1 si falla
     */
    public long saveFormVersion(String json, String tipoFormulario, int userId, int caseId) {
        boolean isFirstForm = !caseCaptureRepository.hasActiveForm(caseId);

        long generatedId = caseCaptureRepository.saveVersionedForm(json, tipoFormulario, userId, caseId);

        if (generatedId > 0 && isFirstForm) {
            log.info("Primer formulario guardado para caseId={}. Disparando evento SAVE_FIRST_FORM.", caseId);
            changeStatusTransactional(caseId, Status.READ, Status.CAPTURE, CaseEvent.SAVE_FIRST_FORM, userId);
        }

        return generatedId;
    }

    /**
     * Obtiene el formulario activo del caso.
     *
     * @param caseId identificador del caso
     * @return formulario activo
     */
    public Optional<CaptureForm> findActiveForm(int caseId) {
        return caseCaptureRepository.findActiveForm(caseId);
    }

    /**
     * Obtiene el historial de formularios del caso.
     *
     * @param caseId identificador del caso
     * @return lista de formularios
     */
    public List<CaptureForm> findFormHistory(int caseId) {
        return caseCaptureRepository.findAllByCaseId(caseId);
    }


    /**
     * Obtiene el detalle de un caso.
     *
     * @param caseId identificador del caso
     * @return detalle del caso
     */
    public Optional<CaseDetail> findCaseById(int caseId) {
        return caseDetailRepository.findById(caseId);
    }

    /**
     * Obtiene el complemento asociado al token del caso.
     *
     * @param idToken token del caso (id_token de DEV_SOLICITUD)
     * @return complemento
     */
    public Optional<String> findComplemento(String idToken) {
        return addendumRepository.findByFolio(idToken);
    }

    /**
     * Guarda un complemento.
     *
     * @param idToken token del caso (id_token de DEV_SOLICITUD)
     * @param json    contenido
     * @param userId  identificador del usuario
     * @return true si se guardó correctamente
     */
    public boolean saveComplemento(String idToken, String json, int userId) {
        return addendumRepository.save(idToken, json, userId);
    }

    /**
     * Actualiza un complemento existente.
     *
     * @param idToken token del caso (id_token de DEV_SOLICITUD)
     * @param json    contenido
     * @param userId  identificador del usuario
     * @return true si se actualizó correctamente
     */
    public boolean updateComplemento(String idToken, String json, int userId) {
        return addendumRepository.update(idToken, json, userId);
    }

    // ── Validación y transición READY ─────────────────────────────────────────

    /**
     * Construye el checklist de validación para el caso a partir de JSON_CAPTURA.
     *
     * <p>Solo el formulario activo (activo=1) es fuente de verdad.
     * Cada criterio del formulario produce un {@link ChecklistGroup} con sus ítems AUTO y MANUAL.
     * Los ítems MANUAL provienen de todos los arrays de tipos de reporte manuales del bloque.
     * Los ítems AUTO provienen de allUsageReportType y los flags deviceHistory / suscriberHistory,
     * filtrados por las capacidades del {@link CriteriaType}.
     *
     * @param caseId identificador del caso
     * @return lista de grupos del checklist, uno por criterio de búsqueda
     * @throws CaseSaveException si no existe formulario activo o su JSON es inválido
     */
    public List<ChecklistGroup> buildChecklist(long caseId) throws CaseSaveException {
        CaptureForm form = caseCaptureRepository.findActiveForm((int) caseId)
                .orElseThrow(() -> new CaseSaveException(
                        "No existe formulario activo para el caso."));

        String json = form.getJsonForm();
        if (json == null || json.isBlank()) {
            throw new CaseSaveException("El formulario activo no contiene datos válidos.");
        }

        return buildGroupsFromJson(json);
    }

    /**
     * Parsea el JSON_CAPTURA y construye los grupos del checklist.
     * Un grupo por cada criterio encontrado en cada bloque del formulario.
     *
     * @param json contenido de la columna JSON_CAPTURA
     * @return lista de grupos, posiblemente vacía si el JSON no contiene criterios válidos
     */
    private List<ChecklistGroup> buildGroupsFromJson(String json) {
        List<ChecklistGroup> groups = new ArrayList<>();
        try (JsonReader reader = Json.createReader(new StringReader(json))) {
            JsonArray blocks = reader.readArray();
            for (JsonValue blockVal : blocks) {
                if (blockVal.getValueType() != JsonValue.ValueType.OBJECT) continue;
                JsonObject block = blockVal.asJsonObject();

                LocalDateTime startDate = parseBlockDate(block, "startDate");
                LocalDateTime endDate   = parseBlockDate(block, "endDate");

                // Recolectar entradas MANUAL: [reportType, label]
                List<String[]> manualEntries = new ArrayList<>();
                collectReportEntries(manualEntries, block, "standardReportTypes");
                collectReportEntries(manualEntries, block, "onDemandReportTypes");
                collectReportEntries(manualEntries, block, "cdrsReportTypes");
                collectReportEntries(manualEntries, block, "cdrsRoamingReportTypes");
                collectReportEntries(manualEntries, block, "coverageTypes");

                // Recolectar entradas AUTO: array allUsageReportTypes + flags de bloque
                String allUsageDirectionLabel = resolveAllUsageDirectionLabel(block);
                List<String[]> autoEntries = new ArrayList<>();
                collectReportEntries(autoEntries, block, "allUsageReportTypes");
                if (block.getBoolean("deviceHistory", false)) {
                    autoEntries.add(new String[]{"DEVICE_HISTORY", HistoryReportType.DEVICE.getLabel()});
                }
                if (block.getBoolean("suscriberHistory", false)) {
                    autoEntries.add(new String[]{"SUBSCRIBER_HISTORY", HistoryReportType.SUSCRIBER.getLabel()});
                }

                // Un grupo por cada criterio del bloque
                JsonArray criteriaArr = block.getJsonArray("criteria");
                if (criteriaArr == null) continue;
                for (JsonValue cv : criteriaArr) {
                    if (cv.getValueType() != JsonValue.ValueType.OBJECT) continue;
                    JsonObject criteriaObj = cv.asJsonObject();

                    String typeName = criteriaObj.getString("criteriaType", null);
                    if (typeName == null) continue;
                    CriteriaType criteriaType;
                    try {
                        criteriaType = CriteriaType.valueOf(typeName.trim().toUpperCase());
                    } catch (IllegalArgumentException e) {
                        log.warn("buildChecklist: criterio desconocido ignorado — tipo={}", typeName);
                        continue;
                    }
                    String criteriaValue = criteriaObj.getString("value", null);

                    // Ítems MANUAL: todos los tipos de reporte manuales del bloque, siempre presentes
                    List<ChecklistItem> manualItems = new ArrayList<>();
                    for (String[] entry : manualEntries) {
                        manualItems.add(ChecklistItem.builder()
                                .criteriaType(criteriaType)
                                .itemType(ChecklistItemType.MANUAL)
                                .reportType(entry[0])
                                .reportTypeLabel(entry[1])
                                .manualResult(null)
                                .build());
                    }

                    // Ítems AUTO: filtrados por las capacidades del criteriaType
                    List<ChecklistItem> autoItems = new ArrayList<>();
                    for (String[] entry : autoEntries) {
                        boolean include = switch (entry[0]) {
                            case "DEVICE_HISTORY"     -> criteriaType.isAllowDeviceHistory();
                            case "SUBSCRIBER_HISTORY" -> criteriaType.isAllowsSuscriberHistory();
                            default                   -> criteriaType.isAllowsAutomatic();
                        };
                        if (include) {
                            boolean isAllUsage = !entry[0].equals("DEVICE_HISTORY")
                                    && !entry[0].equals("SUBSCRIBER_HISTORY");
                            autoItems.add(ChecklistItem.builder()
                                    .criteriaType(criteriaType)
                                    .itemType(ChecklistItemType.AUTO)
                                    .reportType(entry[0])
                                    .reportTypeLabel(entry[1])
                                    .allUsageDirection(isAllUsage ? allUsageDirectionLabel : null)
                                    .build());
                        }
                    }

                    groups.add(ChecklistGroup.builder()
                            .criteriaType(criteriaType)
                            .criteriaValue(criteriaValue)
                            .startDate(startDate)
                            .endDate(endDate)
                            .manualItems(manualItems)
                            .autoItems(autoItems)
                            .build());
                }
            }
        } catch (Exception e) {
            log.warn("buildChecklist: error parseando JSON_CAPTURA", e);
        }
        return groups;
    }

    /**
     * Extrae los valores de un array JSON del bloque y los agrega a la lista de entradas,
     * resolviendo la etiqueta legible desde el enum correspondiente al nombre del array.
     *
     * @param target    lista destino; cada entrada es [reportType, label]
     * @param block     objeto JSON del bloque
     * @param arrayName nombre de la propiedad JSON (ej. "standardReportTypes")
     */
    private void collectReportEntries(List<String[]> target, JsonObject block, String arrayName) {
        JsonArray arr = block.getJsonArray(arrayName);
        if (arr == null || arr.isEmpty()) return;
        for (JsonValue jv : arr) {
            if (jv.getValueType() != JsonValue.ValueType.STRING) continue;
            String val = ((jakarta.json.JsonString) jv).getString();
            target.add(new String[]{val, resolveReportLabel(val, arrayName)});
        }
    }

    /**
     * Resuelve la etiqueta legible de un tipo de reporte a partir de su nombre y array de origen.
     * Si el valor no corresponde a ningún enum conocido devuelve el nombre tal cual.
     *
     * @param reportType nombre del valor del enum (ej. "HOLDER_NAMES")
     * @param arrayName  nombre del array JSON de origen
     * @return etiqueta en español o el nombre del reportType si no se resuelve
     */
    private String resolveReportLabel(String reportType, String arrayName) {
        try {
            return switch (arrayName) {
                case "standardReportTypes"    -> StandardReportType.valueOf(reportType).getLabel();
                case "onDemandReportTypes"    -> OnDemandReportType.valueOf(reportType).getLabel();
                case "cdrsReportTypes"        -> CDRsReportType.valueOf(reportType).getLabel();
                case "cdrsRoamingReportTypes" -> CDRsRoamingReportType.valueOf(reportType).getLabel();
                case "coverageTypes"          -> CoverageType.valueOf(reportType).getLabel();
                case "allUsageReportTypes"    -> AllUsageReportType.valueOf(reportType).getLabel();
                default                       -> reportType;
            };
        } catch (IllegalArgumentException e) {
            log.warn("buildChecklist: label no resuelta para reportType={} array={}", reportType, arrayName);
            return reportType;
        }
    }

    /**
     * Resuelve la label del sentido (AllUsageDirection) desde el bloque JSON.
     * Si el campo no existe o no es válido, retorna el label de ALL como valor por defecto.
     *
     * @param block objeto JSON del bloque
     * @return label legible del sentido (ej. "All", "Incoming", "Outgoing")
     */
    private String resolveAllUsageDirectionLabel(JsonObject block) {
        String raw = block.getString("allUsageDirection", AllUsageDirection.ALL.name());
        try {
            return AllUsageDirection.valueOf(raw).getLabel();
        } catch (IllegalArgumentException e) {
            return AllUsageDirection.ALL.getLabel();
        }
    }

    /**
     * Parsea una fecha ISO-8601 almacenada como string JSON en un bloque del formulario.
     *
     * @param block objeto JSON del bloque
     * @param field nombre del campo (startDate o endDate)
     * @return instancia de LocalDateTime o null si el campo está ausente o es inválido
     */
    private LocalDateTime parseBlockDate(JsonObject block, String field) {
        String val = block.getString(field, null);
        if (val == null || val.isBlank()) return null;
        try {
            return LocalDateTime.parse(val);
        } catch (Exception e) {
            log.warn("buildChecklist: fecha inválida ignorada — campo={} valor={}", field, val);
            return null;
        }
    }

    /**
     * Valida el checklist y ejecuta la transición IN_PROGRESS → READY si todo está correcto.
     *
     * <p>Flujo:
     * <ol>
     *   <li>Construye el checklist desde JSON_CAPTURA (fuente de verdad)</li>
     *   <li>Aplica las selecciones manuales proporcionadas por el usuario</li>
     *   <li>Valida ítems AUTO contra el middleware (lifecycle + resultado)</li>
     *   <li>Valida que todos los ítems MANUAL tengan selección</li>
     *   <li>Ejecuta la transición de estado si todo es válido</li>
     * </ol>
     *
     * @param caseId           identificador del caso
     * @param manualSelections mapa de selecciones del usuario: CriteriaType.name() → ManualResult
     * @param userId           identificador del usuario
     * @throws CaseSaveException si alguna validación falla
     */
    public void markReady(long caseId, Map<String, ManualResult> manualSelections, long userId)
            throws CaseSaveException {

        // 1. Construir checklist desde la BD — la UI no es fuente de verdad
        List<ChecklistGroup> groups = buildChecklist(caseId);

        // 2. Validar integridad de manualSelections: advertir claves desconocidas
        // Clave compuesta: criteriaType.name() + ":" + reportType (ej. "MSISDN:HOLDER_NAMES")
        Set<String> expectedManualKeys = groups.stream()
                .flatMap(g -> g.getManualItems().stream()
                        .map(i -> g.getCriteriaType().name() + ":" + i.getReportType()))
                .collect(Collectors.toSet());

        manualSelections.keySet().stream()
                .filter(k -> !expectedManualKeys.contains(k))
                .forEach(k -> log.warn("markReady: clave desconocida en manualSelections — caseId={} key={}", caseId, k));

        // 3. Aplicar selecciones manuales a los ítems MANUAL de cada grupo
        for (ChecklistGroup group : groups) {
            for (ChecklistItem item : group.getManualItems()) {
                String key = group.getCriteriaType().name() + ":" + item.getReportType();
                item.setManualResult(manualSelections.get(key));
            }
        }

        // 4. Validar ítems AUTO con middleware (si existen grupos con AUTO items)
        boolean hasAutoItems = groups.stream().anyMatch(g -> !g.getAutoItems().isEmpty());
        if (hasAutoItems) {
            enrichAutoItems(groups, caseId);
        }

        // 5. Validar cobertura completa de ítems MANUAL
        List<String> manualIncomplete = groups.stream()
                .flatMap(g -> g.getManualItems().stream()
                        .filter(i -> i.getManualResult() == null)
                        .map(i -> g.getCriteriaType().getLabel() + " — " + i.getReportTypeLabel()))
                .toList();

        if (!manualIncomplete.isEmpty()) {
            throw new CaseSaveException(
                    "Debe completar todas las tareas manuales: "
                            + String.join(", ", manualIncomplete));
        }

        // 6. Transición de estado
        changeStatusTransactional(caseId, Status.IN_PROGRESS, Status.READY, CaseEvent.READY_CASE, userId);
    }

    /**
     * Enriquece los ítems AUTO de cada grupo con el status individual por tipo de reporte
     * obtenido del evento COMPLETE del middleware.
     *
     * <p>Coincidencia por suscriptor: {@code criteriaType|criteriaValue}
     * (ej. {@code "MSISDN|521234567890"}).
     *
     * <p>Cada ítem AUTO recibe el status correspondiente a su {@code reportType}
     * dentro de los {@code responded_records} del suscriptor coincidente.
     * Si el tipo de reporte no aparece en la respuesta se asigna ERROR.
     *
     * @param groups grupos del checklist; solo se procesan los que tienen autoItems
     * @param caseId identificador del caso
     * @throws CaseSaveException si el lifecycle no finalizó, hay grupos sin respuesta o ítems con ERROR
     */
    private void enrichAutoItems(List<ChecklistGroup> groups, long caseId) throws CaseSaveException {

        List<ChecklistGroup> autoGroups = groups.stream()
                .filter(g -> !g.getAutoItems().isEmpty())
                .toList();

        int totalAutoItems = autoGroups.stream().mapToInt(g -> g.getAutoItems().size()).sum();
        log.debug("enrichAutoItems: inicio — caseId={} grupos={} autoItems={}", caseId, autoGroups.size(), totalAutoItems);

        MiddlewareJob job = middlewareRepository.findLatestJobByCaseId(caseId)
                .orElseThrow(() -> new CaseSaveException(
                        "No existe ejecución automática registrada para este caso."));

        // Buscar el evento COMPLETE directamente. Se reintenta una vez por latencia de escritura.
        String responseJson = middlewareRepository.findCompleteEventDescriptionByJobId(job.getJobId())
                .orElse(null);

        if (responseJson == null) {
            log.warn("enrichAutoItems: evento COMPLETE no encontrado, reintentando — caseId={} jobId={}",
                    caseId, job.getJobId());
            responseJson = middlewareRepository.findCompleteEventDescriptionByJobId(job.getJobId())
                    .orElseThrow(() -> new CaseSaveException("La última búsqueda automática no ha finalizado."));
            log.info("enrichAutoItems: reintento exitoso — caseId={} jobId={}", caseId, job.getJobId());
        }

        // Map<"CRITERIATYPE|value", Map<"REPORTTYPE", TargetStatus>>
        // Ej: "MSISDN|521234567890" → {"VOICE" → RESULTS_AVAILABLE, "SMS" → NO_RESULTS_AVAILABLE}
        Map<String, Map<String, TargetStatus>> responseMap = parseResponseBySubscriber(responseJson, caseId);

        log.info("enrichAutoItems: respuesta parseada — caseId={} jobId={} suscriptores={}",
                caseId, job.getJobId(), responseMap.size());

        List<String> missingGroups = new ArrayList<>();
        List<String> erroredItems  = new ArrayList<>();

        for (ChecklistGroup group : autoGroups) {
            // Clave de coincidencia: CRITERIATYPE|VALUE (normalizado)
            String groupKey = normalizeTarget(group.getCriteriaType().name())
                    + "|"
                    + (group.getCriteriaValue() != null ? group.getCriteriaValue().trim() : "");

            Map<String, TargetStatus> reportTypeResults = responseMap.get(groupKey);

            if (reportTypeResults == null) {
                // Suscriptor no encontrado en la respuesta → todos sus ítems AUTO quedan en ERROR
                group.getAutoItems().forEach(item -> item.setTargetStatus(TargetStatus.ERROR));
                missingGroups.add(group.getCriteriaType().getLabel() + " [" + group.getCriteriaValue() + "]");
                log.warn("enrichAutoItems: grupo sin respuesta — caseId={} jobId={} groupKey={}",
                        caseId, job.getJobId(), groupKey);
                continue;
            }

            for (ChecklistItem item : group.getAutoItems()) {
                // Normalizar reportType al mismo formato que las claves del mapa de respuesta
                String reportTypeKey = normalizeTarget(item.getReportType());
                TargetStatus status = reportTypeResults.getOrDefault(reportTypeKey, TargetStatus.ERROR);
                item.setTargetStatus(status);

                log.info("enrichAutoItems: status asignado — caseId={} jobId={} groupKey={} reportType={} status={}",
                        caseId, job.getJobId(), groupKey, reportTypeKey, status);

                if (!status.isAcceptable()) {
                    erroredItems.add(group.getCriteriaType().getLabel() + " — " + item.getReportTypeLabel());
                    if (!reportTypeResults.containsKey(reportTypeKey)) {
                        log.warn("enrichAutoItems: reportType ausente en respuesta — caseId={} jobId={} groupKey={} reportType={}",
                                caseId, job.getJobId(), groupKey, reportTypeKey);
                    } else {
                        log.warn("enrichAutoItems: reportType con ERROR — caseId={} jobId={} groupKey={} reportType={}",
                                caseId, job.getJobId(), groupKey, reportTypeKey);
                    }
                }
            }
        }

        log.info("READY summary — caseId={} jobId={} grupos={} autoItems={} gruposSinRespuesta={} ítems con error={}",
                caseId, job.getJobId(), autoGroups.size(), totalAutoItems, missingGroups, erroredItems);

        if (!missingGroups.isEmpty()) {
            throw new CaseSaveException(
                    "No se encontraron resultados del middleware para: "
                            + String.join(", ", missingGroups));
        }

        if (!erroredItems.isEmpty()) {
            throw new CaseSaveException(
                    "La búsqueda automática contiene errores en: "
                            + String.join(", ", erroredItems));
        }
    }

    /**
     * Parsea el RESPONSE JSON del middleware (EVENT_DESCRIPTION del evento COMPLETE) y
     * construye un mapa indexado por suscriptor con sus statuses por tipo de reporte.
     *
     * <p>Estructura del JSON:
     * <pre>
     * root
     *   case_id                              → validado contra caseId
     *   errors[]                             → si no vacío: FAIL INMEDIATO
     *   subscriber_details[]
     *     identified_subscribers[]
     *       subscriber.type                  → criteriaType normalizado (ej. "MSISDN")
     *       subscriber.value                 → valor del criterio (ej. "521234567890")
     *       responded_records[]
     *         type                           → reportType (ej. "voice", "sms", "data")
     *         status                         → RESULTS_AVAILABLE | NO_RESULTS_AVAILABLE | ERROR
     *         errors[]                       → si no vacío: status = ERROR (sobreescribe)
     * </pre>
     *
     * @param json   contenido del campo EVENT_DESCRIPTION del evento COMPLETE
     * @param caseId identificador del caso, validado contra el campo case_id del JSON
     * @return mapa "CRITERIATYPE|value" → "REPORTTYPE" → {@link TargetStatus}
     * @throws CaseSaveException si el JSON es inválido, está vacío o tiene errores estructurales
     */
    private Map<String, Map<String, TargetStatus>> parseResponseBySubscriber(String json, long caseId)
            throws CaseSaveException {

        if (json == null || json.isBlank()) {
            log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={}", caseId, "EVENT_DESCRIPTION nulo o vacío");
            throw new CaseSaveException("La respuesta automática está vacía o es nula.");
        }

        Map<String, Map<String, TargetStatus>> result = new LinkedHashMap<>();

        try (JsonReader reader = Json.createReader(new StringReader(json))) {

            JsonObject root;
            try {
                root = reader.readObject();
            } catch (Exception e) {
                log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={} causa={}", caseId, "JSON malformado", e.getMessage());
                throw new CaseSaveException("La respuesta automática tiene un formato inválido.");
            }

            // 1. Validar case_id antes de cualquier otra validación
            validateCaseId(root, caseId);

            // 2. root.errors → FAIL INMEDIATO
            JsonArray rootErrors = root.getJsonArray("errors");
            if (rootErrors != null && !rootErrors.isEmpty()) {
                log.error("parseResponseBySubscriber: errores globales — caseId={} errors={}", caseId, rootErrors);
                throw new CaseSaveException("La ejecución automática contiene errores globales.");
            }

            // 3. subscriber_details obligatorio
            JsonArray subscriberDetails = root.getJsonArray("subscriber_details");
            if (subscriberDetails == null || subscriberDetails.isEmpty()) {
                log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={}", caseId, "subscriber_details ausente o vacío");
                throw new CaseSaveException("La respuesta automática no contiene datos de búsqueda.");
            }

            for (JsonValue sdVal : subscriberDetails) {
                if (sdVal.getValueType() != JsonValue.ValueType.OBJECT) {
                    log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={} tipo={}", caseId, "nodo de subscriber_details no es OBJECT", sdVal.getValueType());
                    throw new CaseSaveException("La respuesta automática contiene una entrada de subscriber_details inválida.");
                }
                JsonObject sdObj = sdVal.asJsonObject();

                JsonArray identifiedSubscribers = sdObj.getJsonArray("identified_subscribers");
                if (identifiedSubscribers == null || identifiedSubscribers.isEmpty()) {
                    log.warn("parseResponseBySubscriber: identified_subscribers vacío — caseId={} target_id={}",
                            caseId, sdObj.getString("target_id", "?"));
                    continue;
                }

                for (JsonValue isVal : identifiedSubscribers) {
                    if (isVal.getValueType() != JsonValue.ValueType.OBJECT) {
                        log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={} tipo={}", caseId, "nodo de identified_subscribers no es OBJECT", isVal.getValueType());
                        throw new CaseSaveException("La respuesta automática contiene una entrada de identified_subscribers inválida.");
                    }
                    JsonObject isObj = isVal.asJsonObject();

                    // subscriber.type y subscriber.value identifican al suscriptor
                    JsonObject subscriber = isObj.getJsonObject("subscriber");
                    if (subscriber == null) {
                        log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={}", caseId, "subscriber ausente en identified_subscriber");
                        throw new CaseSaveException("La respuesta automática contiene una entrada sin subscriber.");
                    }
                    String subscriberType = subscriber.getString("type", null);
                    String subscriberValue = subscriber.getString("value", null);
                    if (subscriberType == null || subscriberType.isBlank()) {
                        log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={}", caseId, "subscriber.type ausente o vacío");
                        throw new CaseSaveException("La respuesta automática contiene un subscriber sin tipo de identificador.");
                    }

                    // Clave de grupo: TIPO_NORMALIZADO|valor (ej. "MSISDN|521234567890")
                    String groupKey = normalizeTarget(subscriberType)
                            + "|"
                            + (subscriberValue != null ? subscriberValue.trim() : "");

                    JsonArray records = isObj.getJsonArray("responded_records");
                    if (records == null || records.isEmpty()) {
                        log.warn("parseResponseBySubscriber: responded_records vacío — caseId={} groupKey={}", caseId, groupKey);
                        continue;
                    }

                    Map<String, TargetStatus> recordMap = result.computeIfAbsent(groupKey, k -> new LinkedHashMap<>());

                    for (JsonValue recVal : records) {
                        if (recVal.getValueType() != JsonValue.ValueType.OBJECT) {
                            log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={} groupKey={} tipo={}", caseId, "nodo de responded_records no es OBJECT", groupKey, recVal.getValueType());
                            throw new CaseSaveException("La respuesta automática contiene un registro inválido para: " + groupKey);
                        }
                        JsonObject record = recVal.asJsonObject();

                        String recordType = record.getString("type", null);
                        if (recordType == null || recordType.isBlank()) {
                            log.warn("parseResponseBySubscriber: type ausente en responded_record — caseId={} groupKey={}", caseId, groupKey);
                            continue;
                        }
                        String recordTypeKey = normalizeTarget(recordType);

                        // errors[] no vacío → ERROR sobreescribe cualquier status
                        JsonArray recErrors = record.getJsonArray("errors");
                        TargetStatus status;
                        if (recErrors != null && !recErrors.isEmpty()) {
                            log.warn("parseResponseBySubscriber: errores en record — caseId={} groupKey={} type={} errors={}",
                                    caseId, groupKey, recordTypeKey, recErrors);
                            status = TargetStatus.ERROR;
                        } else {
                            String statusStr = record.getString("status", null);
                            if (!TargetStatus.isKnown(statusStr)) {
                                log.error("parseResponseBySubscriber: status desconocido — caseId={} groupKey={} type={} status={}",
                                        caseId, groupKey, recordTypeKey, statusStr);
                                throw new CaseSaveException(
                                        "La respuesta automática contiene un estado desconocido ["
                                                + statusStr + "] para " + groupKey + "/" + recordType);
                            }
                            status = TargetStatus.fromString(statusStr);
                        }

                        // Si el mismo recordType aparece más de una vez, el peor status tiene precedencia
                        recordMap.merge(recordTypeKey, status, (existing, incoming) -> {
                            if (existing == TargetStatus.ERROR || incoming == TargetStatus.ERROR)
                                return TargetStatus.ERROR;
                            if (existing == TargetStatus.NO_RESULTS_AVAILABLE || incoming == TargetStatus.NO_RESULTS_AVAILABLE)
                                return TargetStatus.NO_RESULTS_AVAILABLE;
                            return TargetStatus.RESULTS_AVAILABLE;
                        });

                        log.debug("parseResponseBySubscriber: record — caseId={} groupKey={} type={} status={}",
                                caseId, groupKey, recordTypeKey, status);
                    }
                }
            }

            if (result.isEmpty()) {
                log.error("parseResponseBySubscriber: error estructural — caseId={} detalle={}", caseId, "sin suscriptores válidos tras procesar la respuesta");
                throw new CaseSaveException("La respuesta automática no contiene registros válidos.");
            }

        } catch (CaseSaveException e) {
            throw e;
        } catch (Exception e) {
            log.error("parseResponseBySubscriber: error inesperado — caseId={} causa={}", caseId, e.getMessage(), e);
            throw new CaseSaveException("La respuesta automática tiene un formato inválido.");
        }

        return result;
    }


    /**
     * Valida que el campo {@code case_id} del RESPONSE JSON coincida con el caso en proceso.
     *
     * <p>El campo puede ser número JSON o string numérico. Se convierte a {@code long}
     * en ambos casos para garantizar comparación por valor lógico, no por representación textual.
     *
     * @param root   objeto raíz del RESPONSE JSON
     * @param caseId identificador del caso en proceso
     * @throws CaseSaveException si el campo no existe, no es numérico, o no coincide
     */
    private void validateCaseId(JsonObject root, long caseId) throws CaseSaveException {
        JsonValue caseIdValue = root.get("case_id");

        if (caseIdValue == null || caseIdValue.getValueType() == JsonValue.ValueType.NULL) {
            log.error("validateCaseId: error estructural — caseId={} detalle={}", caseId, "campo case_id ausente o nulo en la respuesta");
            throw new CaseSaveException("Respuesta automática no contiene case_id.");
        }

        long parsedCaseId;

        if (caseIdValue.getValueType() == JsonValue.ValueType.NUMBER) {
            parsedCaseId = root.getJsonNumber("case_id").longValue();
        } else if (caseIdValue.getValueType() == JsonValue.ValueType.STRING) {
            String s = root.getString("case_id", "").trim();
            if (s.isBlank()) {
                log.error("validateCaseId: error estructural — caseId={} detalle={}", caseId, "case_id es string vacío");
                throw new CaseSaveException("Respuesta automática contiene case_id inválido.");
            }
            try {
                parsedCaseId = Long.parseLong(s);
            } catch (NumberFormatException e) {
                log.error("validateCaseId: error estructural — caseId={} detalle={} valor={}", caseId, "case_id no es numérico", s);
                throw new CaseSaveException("Respuesta automática contiene case_id inválido — debe ser numérico.");
            }
        } else {
            log.error("validateCaseId: error estructural — caseId={} detalle={} tipo={}", caseId, "case_id tiene tipo JSON inesperado", caseIdValue.getValueType());
            throw new CaseSaveException("Respuesta automática contiene case_id inválido.");
        }

        if (parsedCaseId != caseId) {
            log.error("validateCaseId: mismatch — expected={} received={}", caseId, parsedCaseId);
            throw new CaseSaveException("Respuesta automática no corresponde al caso solicitado.");
        }
    }

    /**
     * Normaliza un nombre de target para comparación case-insensitive.
     * Se aplica tanto al nombre del criterio del checklist como al target del middleware.
     *
     * @param value nombre a normalizar
     * @return valor en mayúsculas sin espacios extremos, o cadena vacía si es null
     */
    private static String normalizeTarget(String value) {
        if (value == null) return "";
        return value.trim().toUpperCase();
    }
}
