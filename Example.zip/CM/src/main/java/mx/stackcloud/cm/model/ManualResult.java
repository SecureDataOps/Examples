package mx.stackcloud.cm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Resultado posible que el usuario asigna a un ítem MANUAL del checklist.
 */
@AllArgsConstructor
@Getter
public enum ManualResult {
    RECHAZADO("Rechazado"),
    NO_RESULTADOS("Sin Resultados"),
    SE_ENTREGARA("Se Entregará");

    private final String label;
}
