package mx.stackcloud.cm.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Representa un ítem dentro del checklist de validación para la transición a READY.
 *
 * Los ítems AUTO se enriquecen con el resultado del middleware.
 * Los ítems MANUAL requieren que el usuario seleccione un resultado explícito.
 *
 * La estructura del checklist se construye exclusivamente desde JSON_CAPTURA.
 * El middleware solo enriquece, nunca define ítems.
 */
@Builder
@Getter
public class ChecklistItem {

    /** Tipo de criterio al que corresponde este ítem. */
    private final CriteriaType criteriaType;

    /** Determina si el ítem se valida automáticamente o requiere acción manual. */
    private final ChecklistItemType itemType;

    /**
     * Solo AUTO — estado obtenido del RESPONSE JSON del middleware.
     * Null si aún no se ha enriquecido.
     */
    @Setter
    private TargetStatus targetStatus;

    /**
     * Nombre canónico del tipo de reporte que representa este ítem.
     * Para ítems MANUAL: valor del enum de origen (ej. "HOLDER_NAMES", "VOICE_SENT").
     * Para ítems AUTO: valor del enum allUsageReportType o centinela de flag ("DEVICE_HISTORY", "SUBSCRIBER_HISTORY").
     */
    @Setter
    private String reportType;

    /**
     * Etiqueta legible para el usuario correspondiente a {@link #reportType}.
     * Se resuelve en tiempo de construcción desde el enum de origen.
     */
    @Setter
    private String reportTypeLabel;

    /**
     * Solo ítems AUTO de AllUsageReportType — label del sentido seleccionado (All, Incoming, Outgoing).
     * Null para ítems que no provienen de allUsageReportTypes.
     */
    @Setter
    private String allUsageDirection;

    /**
     * Solo MANUAL — valor seleccionado por el usuario.
     * Null si el usuario aún no ha seleccionado.
     */
    @Setter
    private ManualResult manualResult;

    /**
     * Retorna true si el ítem está correctamente completado.
     * AUTO: targetStatus debe ser RESULT_AVAILABLE o NO_RESULTS.
     * MANUAL: manualResult debe estar seleccionado.
     */
    public boolean isComplete() {
        if (itemType == ChecklistItemType.AUTO) {
            return targetStatus != null && targetStatus.isAcceptable();
        }
        return manualResult != null;
    }
}
