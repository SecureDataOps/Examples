package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum OnDemandReportType {
    USER_NAMES("Nombre(s) (Usuario)"),
    UFMI("UFMI"),
    ACCOUNT_STATUS("Status (Activado o Desactivado)"),
    ACTIVATION_DATE("Fecha de Activación"),
    DEACTIVATION_REASON("Motivo de la Desactivación"),
    SUSPENSION_DATE("Fecha de Suspensión"),
    SUSPENSION_REASON("Motivo de la Suspensión"),
    CONTRACT_NUMBER("Número de Contrato"),
    ACCOUNT_NUMBER("Número de Cuenta"),
    RFC("RFC"),
    PAYMENT_METHOD("Forma de Pago - Crédito o Efectivo"),
    REGISTERED_CREDIT_CARD("Tarjeta de Crédito Registrada"),
    ASSOCIATED_CREDIT_CARDS("Tarjetas de Crédito Asociadas (cada pago) "),
    PAYMENT_RESPONSIBLE("Responsable de Pago"),
    PAYMENT_AMOUNT("Monto de Pago"),
    SIM_PURCHASE_DATE_PLACE("Fecha y lugar de la compra del SIM o del dispositivo"),
    LEGAL_REP_NAME("Nombre de Representante Legal"),
    INVOICES("Facturas"),
    PREPAID_RECHARGES("Recargas de Prepago"),
    PLAN_TYPE("Tipo de Plan Tarifario"),
    TECHNOLOGIES("Tecnologías (2G,3G,4G)"),
    DEVICE_SERIAL("Número de Serie del Dispositivo"),
    FUNCTIONALITIES("Funcionalidades"),
    ASSOCIATED_EMAIL("E-mail Asociado"),
    ACCOUNT_CREATION_DATE("Fecha de Creación de la Cuenta"),
    ACCOUNT_DEACTIVATION_DATE("Fecha de Desactivación de la Cuenta "),
    CURRENT_ACCOUNT_STATUS("Estado de la Cuenta"),
    BILLING_CYCLE("Ciclo de Facturación"),
    HOME_NETWORK_NAME("Nombre de la Red Doméstica del Cliente"),
    PORTABILITY_DATE("Fecha de Portabilidad");

    private final String label;

    OnDemandReportType(String label) {
        this.label = label;
    }
}
