package mx.stackcloud.cm.common.util;

import jakarta.json.bind.Jsonb;
import jakarta.json.bind.JsonbBuilder;
import mx.stackcloud.cm.model.AllUsageReportType;
import mx.stackcloud.cm.model.BlockSummary;
import mx.stackcloud.cm.model.CDRsReportType;
import mx.stackcloud.cm.model.CDRsRoamingReportType;
import mx.stackcloud.cm.model.CoverageType;
import mx.stackcloud.cm.model.CriteriaValue;
import mx.stackcloud.cm.model.FormSummary;
import mx.stackcloud.cm.model.OnDemandReportType;
import mx.stackcloud.cm.model.ReportBlock;
import mx.stackcloud.cm.model.StandardReportType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;

/**
 * Clase utilitaria para construir un {@link FormSummary} a partir de un snapshot JSON.
 *
 * <p>El JSON de entrada corresponde a la columna {@code JSON_FORM} almacenada en
 * CM_FORM_CAPTURA_HISTORICO y representa una lista serializada de {@link ReportBlock}.
 *
 * <p>Todos los errores de parseo se manejan internamente y se registran en logs.
 * Nunca se lanzan excepciones al consumidor y siempre se retorna un resultado no nulo.
 *
 * <p>Es una clase utilitaria estática y no puede ser instanciada.
 */
public final class FormSummaryBuilder {

    private static final Logger log = LoggerFactory.getLogger(FormSummaryBuilder.class);

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private FormSummaryBuilder() {
        // static utility class — no instances
    }

    /**
     * Construye un {@link FormSummary} a partir de un snapshot JSON.
     *
     * <p>El JSON debe representar una lista de {@link ReportBlock}, tal como lo genera
     * {@code generarJsonDesdeFormulario()}.
     *
     * @param json cadena JSON con la lista de bloques; puede ser null o vacía
     * @return un {@link FormSummary} poblado; nunca null. Retorna un resumen vacío si
     *         el input es null, vacío o no puede parsearse
     */
    public static FormSummary buildFromJson(String json) {
        FormSummary summary = new FormSummary();
        if (json == null || json.isBlank()) return summary;

        List<ReportBlock> blocks = deserialize(json);
        if (blocks == null || blocks.isEmpty()) return summary;

        boolean anyDevice    = false;
        boolean anySuscriber = false;
        int idx = 1;

        for (ReportBlock b : blocks) {

            if (b.isDeviceHistory())    anyDevice    = true;
            if (b.isSuscriberHistory()) anySuscriber = true;

            BlockSummary block = BlockSummary.builder()
                    .numero(idx++)
                    .fechaInicio(b.getStartDate() != null ? b.getStartDate().format(DATE_FMT) : "—")
                    .fechaFin(b.getEndDate()   != null ? b.getEndDate().format(DATE_FMT)   : "—")
                    .criterios(buildCriterios(b))
                    .reportes(buildReportes(b))
                    .coberturas(buildCoberturas(b))
                    .deviceHistory(b.isDeviceHistory())
                    .suscriberHistory(b.isSuscriberHistory())
                    .build();

            summary.getBloques().add(block);
        }

        summary.setDeviceHistory(anyDevice);
        summary.setSuscriberHistory(anySuscriber);

        return summary;
    }

    /**
     * Compara dos instancias de {@link FormSummary} y devuelve sus diferencias.
     *
     * <p>La comparación es posicional: cada bloque en {@code current} se compara con
     * el bloque en la misma posición en {@code previous}.
     *
     * <p>Incluye diferencias en número de bloques, rangos de fechas, criterios,
     * reportes, coberturas y banderas de históricos.
     *
     * @param current  resumen actual (más reciente)
     * @param previous resumen anterior
     * @return lista de diferencias legibles; nunca null. Retorna lista vacía si
     *         alguno es null, o un único mensaje si no hay diferencias
     */
    public static List<String> diff(FormSummary current, FormSummary previous) {
        if (current == null || previous == null) return Collections.emptyList();

        List<String> diffs = new ArrayList<>();

        int curSize  = current.getBloques()  == null ? 0 : current.getBloques().size();
        int prevSize = previous.getBloques() == null ? 0 : previous.getBloques().size();

        if (curSize != prevSize) {
            diffs.add("Número de bloques: " + prevSize + " → " + curSize);
        }

        int limit = Math.min(curSize, prevSize);
        for (int i = 0; i < limit; i++) {
            BlockSummary cur  = current.getBloques().get(i);
            BlockSummary prev = previous.getBloques().get(i);
            String prefix = "Bloque " + (i + 1) + ": ";

            diffField(diffs, prefix + "Fecha inicio", prev.getFechaInicio(), cur.getFechaInicio());
            diffField(diffs, prefix + "Fecha fin",    prev.getFechaFin(),    cur.getFechaFin());

            if (!cur.getCriterios().equals(prev.getCriterios())) {
                diffs.add(prefix + "Criterios cambiaron");
            }
            if (!cur.getReportes().equals(prev.getReportes())) {
                diffs.add(prefix + "Reportes cambiaron");
            }
            if (!cur.getCoberturas().equals(prev.getCoberturas())) {
                diffs.add(prefix + "Coberturas cambiaron");
            }
            diffBool(diffs, prefix + "Histórico de dispositivo",
                    prev.isDeviceHistory(), cur.isDeviceHistory());
            diffBool(diffs, prefix + "Histórico de suscriptor",
                    prev.isSuscriberHistory(), cur.isSuscriberHistory());
        }

        if (diffs.isEmpty()) {
            diffs.add("Sin diferencias detectadas entre versiones.");
        }

        return diffs;
    }

    /**
     * Deserializa una cadena JSON a una lista de {@link ReportBlock}.
     *
     * @param json cadena JSON a deserializar
     * @return lista de bloques o lista vacía si ocurre un error
     */
    private static List<ReportBlock> deserialize(String json) {
        try (Jsonb jsonb = JsonbBuilder.create()) {
            return jsonb.fromJson(json,
                    new ArrayList<ReportBlock>() {}.getClass().getGenericSuperclass());
        } catch (Exception e) {
            log.warn("FormSummaryBuilder: failed to deserialize JSON snapshot — {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    /**
     * Extrae y formatea los criterios de un bloque.
     *
     * @param b bloque de origen
     * @return lista de criterios formateados; nunca null
     */
    private static List<String> buildCriterios(ReportBlock b) {
        List<String> list = new ArrayList<>();
        if (b.getCriteria() == null) return list;
        for (CriteriaValue c : b.getCriteria()) {
            if (c.getCriteriaType() != null
                    && c.getValue() != null
                    && !c.getValue().isBlank()) {
                list.add(c.getCriteriaType().getLabel() + ": " + c.getValue().trim());
            }
        }
        return list;
    }

    /**
     * Extrae y formatea los tipos de reportes de un bloque.
     *
     * @param b bloque de origen
     * @return lista de etiquetas de reportes; nunca null
     */
    private static List<String> buildReportes(ReportBlock b) {
        List<String> list = new ArrayList<>();
        addLabels(list, b.getStandardReportTypes(),    StandardReportType::getLabel);
        addLabels(list, b.getOnDemandReportTypes(),    OnDemandReportType::getLabel);
        addLabels(list, b.getCdrsReportTypes(),        CDRsReportType::getLabel);
        addLabels(list, b.getCdrsRoamingReportTypes(), CDRsRoamingReportType::getLabel);
        addLabels(list, b.getAllUsageReportTypes(),     AllUsageReportType::getLabel);
        if (b.getAllUsageDirection() != null) {
            list.add(b.getAllUsageDirection().getLabel());
        }
        return list;
    }

    /**
     * Extrae y formatea los tipos de cobertura de un bloque.
     *
     * @param b bloque de origen
     * @return lista de etiquetas de cobertura; nunca null
     */
    private static List<String> buildCoberturas(ReportBlock b) {
        List<String> list = new ArrayList<>();
        addLabels(list, b.getCoverageTypes(), CoverageType::getLabel);
        return list;
    }

    /**
     * Agrega etiquetas no vacías desde un conjunto origen a una lista destino.
     *
     * @param target lista destino
     * @param source conjunto origen
     * @param labelFn función para obtener la etiqueta de cada elemento
     * @param <T> tipo de elemento
     */
    private static <T> void addLabels(List<String> target, Set<T> source,
                                      Function<T, String> labelFn) {
        if (source == null || source.isEmpty()) return;
        for (T item : source) {
            String label = labelFn.apply(item);
            if (label != null && !label.isBlank()) {
                target.add(label);
            }
        }
    }

    /**
     * Agrega una diferencia si dos valores de texto no son iguales.
     *
     * @param diffs lista de diferencias
     * @param label etiqueta del campo
     * @param prev  valor anterior
     * @param cur   valor actual
     */
    private static void diffField(List<String> diffs, String label,
                                  String prev, String cur) {
        if (!Objects.equals(prev, cur)) {
            diffs.add(label + ": " + prev + " → " + cur);
        }
    }

    /**
     * Agrega una diferencia si dos valores booleanos son distintos.
     *
     * @param diffs lista de diferencias
     * @param label etiqueta del campo
     * @param prev  valor anterior
     * @param cur   valor actual
     */
    private static void diffBool(List<String> diffs, String label,
                                 boolean prev, boolean cur) {
        if (prev != cur) {
            diffs.add(label + ": " + bool(prev) + " → " + bool(cur));
        }
    }

    /**
     * Convierte un valor booleano a texto legible.
     *
     * @param v valor booleano
     * @return "Sí" si es true, en caso contrario "No"
     */
    private static String bool(boolean v) {
        return v ? "Sí" : "No";
    }
}
