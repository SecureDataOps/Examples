package mx.stackcloud.cm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.regex.Pattern;

@AllArgsConstructor
@Getter
public enum CriteriaType {
    MSISDN("MSISDN", true, false, true, null, 10, 10),
    IMSI("IMSI", true, true, false, null, 15, 15),
    IMEI("IMEI", true, true, false, null, 15, 15),
    UFMI("UFMI", true, false, false, null, 10, 10),
    ICCID("ICCID", true, false, false, null, 5, 15),
    NAME("Nombre Completo", true, false, false, null, 3, 100),
    RFC("RFC", false, false, false, null, 10, 13),
    ADDRESS("Direccion", false, false, false, null, 10, 100),
    COMPANY("Compañia", false, false, false, null, 3, 50),
    LEGAL_REPRESENTATIVE("Representante Legal", false, false, false, null, 3, 50),
    CONTRACT("Contrato", false, false, false, null, 3, 50),
    ACCOUNT_NUMBER("Número de Cuenta", false, false, false, null, 3, 50),
    PUBLIC_IP("IP Público", false, false, false, null, 3, 50),
    VISITED_IP("IP Visitado", false, false, false, null, 3, 50),
    ;

    @Getter
    private final String label;
    @Getter
    private final boolean allowsAutomatic;
    @Getter
    private final boolean allowDeviceHistory;
    @Getter
    private final boolean allowsSuscriberHistory;

    private final Pattern pattern;
    @Getter
    private final int minLength;
    @Getter
    private final int maxLength;

    public boolean isValid(String value) {
        if (value == null)
            return false;

        String v = value.trim();

        // Validación base (para TODOS)
        if (v.length() < minLength || v.length() > maxLength)
            return false;

        // Validación específica (si existe)
        if (pattern != null && !pattern.matcher(v).matches())
            return false;

        return true;
    }

}
