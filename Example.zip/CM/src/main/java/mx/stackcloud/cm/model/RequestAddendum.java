package mx.stackcloud.cm.model;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class RequestAddendum {
    public Indicator firstIndicator = new Indicator();
    public Indicator secondIndicator = new Indicator();
    public Indicator thirdIndicator = new Indicator();
    public RequestDates requestDates = new RequestDates();
    public String dealership;
    public String typeRecive;
    public String comments;

    @Getter
    @Setter
    @ToString
    public static class Indicator {
        String label;
        String value;
    }

    @Getter
    @Setter
    @ToString
    public static class RequestDates {

        LocalDateTime deadlineUntil; // o LocalDateTime con formato, ver nota abajo

        LocalDateTime signatureDate;
    }
}