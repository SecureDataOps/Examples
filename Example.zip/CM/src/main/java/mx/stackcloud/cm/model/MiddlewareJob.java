package mx.stackcloud.cm.model;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

/**
 * Representa un registro de la tabla DEV_MIDDLEWARE_JOB.
 * Contiene el identificador del job y metadatos de ejecución.
 */
@Builder
@Getter
public class MiddlewareJob {

    private final long   mjId;
    private final long   jobId;
    private final long   caseId;
    private final String priority;
    private final String status;
    private final LocalDateTime createdOn;
    private final LocalDateTime updateOn;
}
