package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum AllUsageReportType {
    VOICE("Voz"),
    SMS("SMS"),
    DATA("Datos");

    private final String label;

    AllUsageReportType(String label) {
        this.label = label;
    }
}
