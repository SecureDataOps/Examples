package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.repository.BitacoraActualRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * Implementación del repositorio de estado actual del caso (DEV_CASOS).
 *
 * Cada caso tiene exactamente un registro en esta tabla.
 * Se actualiza en cada transición de estado.
 *
 * Patrón de implementación:
 * Los métodos sin Connection abren su propia y delegan en los métodos con Connection.
 * La lógica SQL vive una sola vez — en los métodos con Connection.
 * El repositorio NUNCA cierra una Connection que recibió externamente.
 */
@Named
@ApplicationScoped
public class BitacoraActualRepositoryImpl implements BitacoraActualRepository {

    private static final Logger log = LoggerFactory.getLogger(BitacoraActualRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_FIND_STATUS = """
            SELECT id_estatus
            FROM   APPS.DEV_CASOS
            WHERE  id_caso = ?
            """;

    /**
     * UPDATE con WHERE compuesto (id_caso + id_estatus):
     * garantía de idempotencia y protección ante cambios concurrentes.
     */
    private static final String SQL_UPDATE_STATUS = """
            UPDATE APPS.DEV_CASOS
            SET    id_estatus                  = ?,
                   FECHA_ESTATUS               = SYSDATE,
                   id_usuario_creacion = ?
            WHERE  id_caso                     = ?
              AND  id_estatus                  = ?
            """;

    // ── Métodos sin Connection — abren su propia conexión ────────────────────

    @Override
    public Optional<Integer> findCurrentStatus(long caseId) {
        try (Connection conn = dataSource.getConnection()) {
            return findCurrentStatus(conn, caseId);
        } catch (SQLException e) {
            log.error("DEV_CASOS — findCurrentStatus FAILED: caseId={} causa={}",
                    caseId, e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public int updateCurrentStatus(long caseId, int expectedStatusId, int newStatusId, long userId) {
        try (Connection conn = dataSource.getConnection()) {
            return updateCurrentStatus(conn, caseId, expectedStatusId, newStatusId, userId);
        } catch (SQLException e) {
            log.error("DEV_CASOS — updateCurrentStatus FAILED: caseId={} expected={} new={} causa={}",
                    caseId, expectedStatusId, newStatusId, e.getMessage());
            throw new RuntimeException("Error al actualizar estado en DEV_CASOS", e);
        }
    }

    // ── Métodos con Connection — lógica SQL real ──────────────────────────────

    /**
     * {@inheritDoc}
     *
     * <p>Usa try-with-resources solo para PreparedStatement y ResultSet.
     * La Connection no se cierra — la gestiona el llamador.
     */
    @Override
    public Optional<Integer> findCurrentStatus(Connection conn, long caseId) {
        try (PreparedStatement stmt = conn.prepareStatement(SQL_FIND_STATUS)) {

            stmt.setLong(1, caseId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(rs.getInt("id_estatus"));
                }
            }

        } catch (SQLException e) {
            log.error("DEV_CASOS — findCurrentStatus(conn) FAILED: caseId={} causa={}",
                    caseId, e.getMessage());
            throw new RuntimeException("Error al consultar estado en DEV_CASOS", e);
        }

        return Optional.empty();
    }

    /**
     * {@inheritDoc}
     *
     * <p>Usa try-with-resources solo para PreparedStatement.
     * La Connection no se cierra — la gestiona el llamador.
     * Retornar 0 es un resultado válido (concurrencia), no lanza excepción.
     */
    @Override
    public int updateCurrentStatus(Connection conn, long caseId,
                                   int expectedStatusId, int newStatusId, long userId) {
        try (PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE_STATUS)) {

            stmt.setInt(1, newStatusId);
            stmt.setLong(2, userId);
            stmt.setLong(3, caseId);
            stmt.setInt(4, expectedStatusId);

            return stmt.executeUpdate();

        } catch (SQLException e) {
            log.error("DEV_CASOS — updateCurrentStatus(conn) FAILED: caseId={} expected={} new={} causa={}",
                    caseId, expectedStatusId, newStatusId, e.getMessage());
            throw new RuntimeException("Error al actualizar estado en DEV_CASOS", e);
        }
    }
}
