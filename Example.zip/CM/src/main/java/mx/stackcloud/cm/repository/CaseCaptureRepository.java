package mx.stackcloud.cm.repository;

import mx.stackcloud.cm.model.CaptureForm;

import java.util.List;
import java.util.Optional;

public interface CaseCaptureRepository {

    /**
     * Deactivates all previous active versions and inserts a new one with activo=1.
     * Always INSERT — never UPDATE a form record.
     *
     * @return generated ID of the new version, or -1 on failure
     */
    long saveVersionedForm(String jsonForm, String tipoFormulario, int userId, int caseId);

    /**
     * Returns the single active version (activo=1) for the given case, if any.
     */
    Optional<CaptureForm> findActiveForm(int caseId);

    /**
     * Returns all versions for a case ordered by registration date descending.
     */
    List<CaptureForm> findAllByCaseId(int caseId);

    /**
     * Indica si el caso ya tiene al menos un formulario activo registrado.
     * Se consulta ANTES de guardar para saber si el formulario que se va a insertar
     * es el primero, sin importar el que se insertará a continuación.
     *
     * @param caseId identificador del caso
     * @return true si existe un registro con activo=1 para ese caso
     */
    boolean hasActiveForm(long caseId);
}
