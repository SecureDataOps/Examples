package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum CDRsRoamingReportType {
    VOICE_TAP_IN("Voz Tap-In"),
    VOICE_TAP_OUT("Voz Tap-Out"),
    SMS_TAP_IN("SMS Tap-In"),
    SMS_TAP_OUT("SMS Tap-Out");

    private final String label;

    CDRsRoamingReportType(String label) {
        this.label = label;
    }
}
