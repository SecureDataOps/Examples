package mx.stackcloud.cm.model;

import lombok.Builder;
import lombok.Getter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

/**
 * Immutable, human-readable summary of a single {@link ReportBlock}.
 * Built by {@link mx.stackcloud.cm.common.util.FormSummaryBuilder} — never constructed directly.
 */
@Getter
@Builder
public class BlockSummary implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    /** 1-based block number within the form. */
    private final int numero;

    /** Formatted start date (dd/MM/yyyy HH:mm), or "—" when null. */
    private final String fechaInicio;

    /** Formatted end date (dd/MM/yyyy HH:mm), or "—" when null. */
    private final String fechaFin;

    /**
     * Criteria formatted as "TypeLabel: value".
     * Empty list when no criteria are set or all values are blank.
     */
    private final List<String> criterios;

    /**
     * Human-readable report type labels aggregated from all five report type sets
     * ({@link StandardReportType}, {@link OnDemandReportType}, {@link CDRsReportType},
     * {@link CDRsRoamingReportType}, {@link AllUsageReportType}).
     * Empty list when no report types are selected.
     */
    private final List<String> reportes;

    /**
     * Human-readable coverage labels from {@link CoverageType}.
     * Empty list when no coverage types are selected.
     */
    private final List<String> coberturas;

    /** True when this block requests device history. */
    private final boolean deviceHistory;

    /** True when this block requests subscriber history. */
    private final boolean suscriberHistory;
}
