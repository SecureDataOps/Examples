package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum CDRsReportType {
    VOICE_RECEIVED("Voz - Recibidos"),
    VOICE_SENT("Voz - Enviados"),
    SMS_RECEIVED("SMS - Recibidos"),
    SMS_SENT("SMS - Enviados"),
    DATA("Datos");

    private final String label;

    CDRsReportType(String label) {
        this.label = label;
    }
}
