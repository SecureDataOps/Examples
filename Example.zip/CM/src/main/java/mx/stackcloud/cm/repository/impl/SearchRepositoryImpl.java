package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.model.Search;
import mx.stackcloud.cm.repository.SearchRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Named
@ApplicationScoped
public class SearchRepositoryImpl implements SearchRepository {

    private static final Logger log = LoggerFactory.getLogger(SearchRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_INSERT = """
            INSERT INTO APPS.DEV_FORM_BUSQUEDA
                (CASE_ID, FORM_ID, PARENT_BUSQUEDA_ID, NIVEL, JSON_FORM_SNAPSHOT, USUARIO_ID)
            VALUES
                (?, ?, ?, ?, ?, ?)
            """;

    private static final String SQL_FIND_BY_ID = """
            SELECT ID, CASE_ID, FORM_ID, PARENT_BUSQUEDA_ID, NIVEL,
                   JSON_FORM_SNAPSHOT, USUARIO_ID, FECHA_REGISTRO
            FROM APPS.DEV_FORM_BUSQUEDA
            WHERE ID = ?
            """;

    private static final String SQL_FIND_BY_CASE_ID = """
            SELECT ID, CASE_ID, FORM_ID, PARENT_BUSQUEDA_ID, NIVEL,
                   JSON_FORM_SNAPSHOT, USUARIO_ID, FECHA_REGISTRO
            FROM APPS.DEV_FORM_BUSQUEDA
            WHERE CASE_ID = ?
            ORDER BY NIVEL ASC, ID ASC
            """;

    /**
     * Inserts a search record and returns the Oracle-generated ID.
     * JSON_FORM_SNAPSHOT written via {@link PreparedStatement#setCharacterStream} for CLOB safety.
     * FECHA_REGISTRO is omitted — Oracle fills it with SYSDATE via column default.
     *
     * @throws RuntimeException wrapping the underlying {@link SQLException} so the caller
     *                          (CaseService) can catch and log without aborting the save flow.
     */
    @Override
    public long saveBusqueda(
            long caseId,
            long formId,
            Long parentId,
            int nivel,
            String jsonSnapshot,
            String status,
            int userId) {

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT, new String[]{"ID"})) {

            stmt.setLong(1, caseId);
            stmt.setLong(2, formId);

            if (parentId != null) {
                stmt.setLong(3, parentId);
            } else {
                stmt.setNull(3, Types.NULL);
            }

            stmt.setInt(4, nivel);
            stmt.setCharacterStream(5, new StringReader(jsonSnapshot), (long) jsonSnapshot.length());
            stmt.setInt(6, userId);

            stmt.executeUpdate();

            try (ResultSet keys = stmt.getGeneratedKeys()) {
                if (keys.next()) {
                    long generatedId = keys.getLong(1);
                    log.debug("saveBusqueda inserted id={} caseId={} formId={} nivel={} status={}",
                            generatedId, caseId, formId, nivel, status);
                    return generatedId;
                }
            }

            log.warn("saveBusqueda: no generated key returned for caseId={} formId={}", caseId, formId);
            return -1;

        } catch (SQLException e) {
            log.error("saveBusqueda failed caseId={} formId={} nivel={}: {}",
                    caseId, formId, nivel, e.getMessage());
            throw new RuntimeException(
                    "Failed to persist search record for case " + caseId + ", form " + formId, e);
        }
    }

    /**
     * Retrieves a single search record by primary key.
     * JSON_FORM_SNAPSHOT is read via {@link Clob#getCharacterStream()} to handle payloads of any size.
     */
    @Override
    public Optional<Search> findById(long id) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_BY_ID)) {

            stmt.setLong(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }

        } catch (SQLException e) {
            log.error("findById failed for busquedaId={}: {}", id, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Retrieves all search records for a case ordered NIVEL ASC, ID ASC.
     * This ordering guarantees parents are always processed before their children,
     * enabling single-pass tree construction in the caller.
     */
    @Override
    public List<Search> findByCaseId(long caseId) {
        List<Search> result = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_BY_CASE_ID)) {

            stmt.setLong(1, caseId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }

        } catch (SQLException e) {
            log.error("findByCaseId failed for caseId={}: {}", caseId, e.getMessage());
        }
        return result;
    }

    // ── Mapping ───────────────────────────────────────────────────────────────

    private Search mapRow(ResultSet rs) throws SQLException {
        Search b = new Search();
        b.setId(rs.getLong("ID"));
        b.setCaseId(rs.getLong("CASE_ID"));
        b.setFormId(rs.getLong("FORM_ID"));

        long parentId = rs.getLong("PARENT_BUSQUEDA_ID");
        b.setParentBusquedaId(rs.wasNull() ? null : parentId);

        b.setNivel(rs.getInt("NIVEL"));
        b.setJsonFormSnapshot(readClob(rs, "JSON_FORM_SNAPSHOT"));
        b.setUserId(rs.getInt("USUARIO_ID"));

        LocalDateTime fechaHora = rs.getObject("FECHA_REGISTRO", LocalDateTime.class);
        if (fechaHora != null) {
            b.setFechaRegistro(fechaHora);
        }

        return b;
    }

    /**
     * Reads a CLOB column safely for payloads of any length.
     * Falls back to an empty string if the column is SQL NULL.
     */
    private String readClob(ResultSet rs, String column) throws SQLException {
        Clob clob = rs.getClob(column);
        if (clob == null) return "";

        try (Reader reader = clob.getCharacterStream()) {
            StringBuilder sb = new StringBuilder((int) clob.length());
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, read);
            }
            return sb.toString();
        } catch (IOException e) {
            log.error("readClob failed for column {}: {}", column, e.getMessage());
            return "";
        }
    }
}
