package mx.stackcloud.cm.view;

import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import mx.stackcloud.cm.model.ManualResult;

/**
 * Converter JSF para el enum {@link ManualResult}.
 * Registrado por tipo ({@code forClass}) para que JSF lo aplique automáticamente
 * en cualquier componente cuya propiedad enlazada sea de tipo {@code ManualResult}.
 */
@FacesConverter(forClass = ManualResult.class)
public class ManualResultConverter implements Converter<ManualResult> {

    /**
     * Convierte el valor de cadena enviado por el formulario al enum correspondiente.
     *
     * @param context   contexto de faces
     * @param component componente origen
     * @param value     nombre del enum en cadena; puede ser null o vacío
     * @return instancia del enum o null si el valor está vacío
     */
    @Override
    public ManualResult getAsObject(FacesContext context, UIComponent component, String value) {
        if (value == null || value.isBlank()) return null;
        return ManualResult.valueOf(value);
    }

    /**
     * Convierte el enum a su representación en cadena para el HTML generado.
     *
     * @param context   contexto de faces
     * @param component componente destino
     * @param value     instancia del enum; puede ser null
     * @return nombre del enum o cadena vacía si es null
     */
    @Override
    public String getAsString(FacesContext context, UIComponent component, ManualResult value) {
        return value != null ? value.name() : "";
    }
}
