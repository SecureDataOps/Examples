package mx.stackcloud.cm.model;

import java.io.Serial;
import java.io.Serializable;
import java.util.UUID;

public class CriteriaValue implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String uuid;
    private CriteriaType criteriaType;
    private String value;

    /**
     * Default constructor. Generates a new UUID.
     */
    public CriteriaValue() {
        this.uuid = UUID.randomUUID().toString();
    }

    /**
     * Constructor with specific criteria type and value.
     *
     * @param criteriaType The type of criteria.
     * @param value        The string value for this criteria.
     */
    public CriteriaValue(CriteriaType criteriaType, String value) {
        this();
        this.criteriaType = criteriaType;
        this.value = value;
    }

    /**
     * Gets the unique identifier of this criteria value.
     *
     * @return The UUID string.
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * Sets the unique identifier for this criteria value.
     *
     * @param uuid The UUID string to set.
     */
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    /**
     * Gets the criteria type.
     *
     * @return The CriteriaType enum value.
     */
    public CriteriaType getCriteriaType() {
        return criteriaType;
    }

    /**
     * Sets the criteria type.
     *
     * @param criteriaType The CriteriaType enum value to set.
     */
    public void setCriteriaType(CriteriaType criteriaType) {
        this.criteriaType = criteriaType;
    }

    /**
     * Gets the value provided for this criteria.
     *
     * @return The string value.
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value for this criteria.
     *
     * @param value The string value to set.
     */
    public void setValue(String value) {
        this.value = value;
    }
}
