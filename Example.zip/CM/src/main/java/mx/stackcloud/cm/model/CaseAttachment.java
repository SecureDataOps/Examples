package mx.stackcloud.cm.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class CaseAttachment implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private int emailId;
    private String filename;
    private String path;
    private LocalDateTime registrationDate;
}
