package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum CoverageType {
    COVERAGE1("Latitud & Longitud"),
    COVERAGE2("Cell Name"),
    COVERAGE3("Tower Name"),
    COVERAGE4("Node B Name"),
    COVERAGE5("Site Name"),
    COVERAGE6("LAC (3G)"),
    COVERAGE7("Cell ID (3G)"),
    COVERAGE8("CGI (3G)"),
    COVERAGE9("CID (3G)"),
    COVERAGE10("Node B ID (4G)"),
    COVERAGE11("TAC (4G)"),
    COVERAGE12("Poligono de Cobertura");

    private final String label;

    CoverageType(String label) {
        this.label = label;
    }
}
