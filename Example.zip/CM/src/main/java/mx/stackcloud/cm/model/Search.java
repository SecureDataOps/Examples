package mx.stackcloud.cm.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Represents a single search record stored in CM_FORM_BUSQUEDA.
 *
 * <p>Each instance is a node in the search tree for a given case:
 * <ul>
 *   <li>nivel 1 — initial search, {@code parentBusquedaId} is {@code null}</li>
 *   <li>nivel N — chained search, {@code parentBusquedaId} points to the parent node</li>
 * </ul>
 *
 * <p>{@code jsonFormSnapshot} is the immutable capture of the form at the moment the search
 * was triggered. It must never be modified after insertion.
 */
@Getter
@Setter
@NoArgsConstructor
public class Search implements Serializable {
    private static final long serialVersionUID = 1L;

    private long id;
    private long caseId;
    private long formId;
    /** {@code null} for nivel-1 searches; points to the parent {@link Search#id} otherwise. */
    private Long parentBusquedaId;
    private int nivel;
    /** Immutable JSON snapshot of the form at search time. Never re-serialized or transformed. */
    private String jsonFormSnapshot;
    private int userId;
    private LocalDateTime fechaRegistro;


    /** {@code true} if this is a root-level search (no parent). */
    public boolean isInitial() {
        return parentBusquedaId == null;
    }
}
