package mx.stackcloud.cm.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Agrupa los ítems de checklist correspondientes a un único criterio de búsqueda.
 *
 * <p>Cada grupo proviene de un criterio dentro de un bloque de JSON_CAPTURA.
 * Mantiene separados los ítems automáticos (validados contra el middleware)
 * y los manuales (requieren selección explícita del usuario).
 */
@Builder
@Getter
public class ChecklistGroup {

    /** Tipo de criterio al que pertenece este grupo (MSISDN, IMEI, RFC…). */
    private final CriteriaType criteriaType;

    /** Valor concreto del criterio capturado en el formulario (ej. número telefónico, IMEI). */
    private final String criteriaValue;

    /** Fecha de inicio del periodo de búsqueda del bloque origen. */
    private final LocalDateTime startDate;

    /** Fecha de fin del periodo de búsqueda del bloque origen. */
    private final LocalDateTime endDate;

    /**
     * Ítems que requieren acción manual del usuario.
     * Fuentes: standardReportTypes, onDemandReportTypes, cdrsReportTypes,
     * cdrsRoamingReportTypes, coverageTypes.
     */
    @Setter
    private List<ChecklistItem> manualItems;

    /**
     * Ítems validados automáticamente contra el middleware.
     * Fuentes: allUsageReportType, flags deviceHistory y suscriberHistory
     * (filtrados por las capacidades del criteriaType).
     */
    @Setter
    private List<ChecklistItem> autoItems;

    /**
     * Retorna el periodo del bloque formateado como "dd/MM/yyyy - HH:mm / dd/MM/yyyy - HH:mm".
     */
    public String getFormattedPeriod() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy - HH:mm");
        String start = startDate != null ? startDate.format(fmt) : "—";
        String end   = endDate   != null ? endDate.format(fmt)   : "—";
        return start + " / " + end;
    }

    /**
     * Indica si todos los ítems del grupo están completados.
     *
     * @return true si todos los ítems manuales tienen selección y todos los AUTO tienen estado aceptable
     */
    public boolean isComplete() {
        boolean manualOk = manualItems == null || manualItems.stream().allMatch(ChecklistItem::isComplete);
        boolean autoOk = autoItems == null || autoItems.stream().allMatch(ChecklistItem::isComplete);
        return manualOk && autoOk;
    }
}
