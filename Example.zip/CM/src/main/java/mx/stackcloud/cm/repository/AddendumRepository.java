package mx.stackcloud.cm.repository;

import java.util.Optional;

public interface AddendumRepository {
    Optional<String> findByFolio(String folio);
    boolean save(String folio, String json, int userId);
    boolean update(String folio, String json, int userId);
}
