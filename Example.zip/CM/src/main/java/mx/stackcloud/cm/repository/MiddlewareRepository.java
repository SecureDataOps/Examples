package mx.stackcloud.cm.repository;

import mx.stackcloud.cm.model.MiddlewareJob;

import java.util.Optional;

/**
 * Acceso de solo lectura a las tablas de middleware.
 * No modifica datos — el middleware es un sistema externo de solo consulta.
 */
public interface MiddlewareRepository {

    /**
     * Obtiene el job más reciente asociado al caso.
     *
     * @param caseId identificador del caso
     * @return job más reciente o vacío si no existe
     */
    Optional<MiddlewareJob> findLatestJobByCaseId(long caseId);

    /**
     * Obtiene el nombre del evento más reciente para el job indicado.
     * Permite saber si el job está en ACKNOWLEDGED, COMPLETE o ERROR.
     *
     * @param jobId identificador del job en DEV_MIDDLEWARE_JOB
     * @return nombre del evento o vacío si no existen eventos
     */
    Optional<String> findLatestEventByJobId(long jobId);

    /**
     * Obtiene el EVENT_DESCRIPTION del evento COMPLETE más reciente del job.
     * Este campo contiene el RESPONSE JSON con el array de targets y sus resultados.
     *
     * @param jobId identificador del job en DEV_MIDDLEWARE_JOB
     * @return JSON de respuesta o vacío si no existe evento COMPLETE
     */
    Optional<String> findCompleteEventDescriptionByJobId(long jobId);
}
