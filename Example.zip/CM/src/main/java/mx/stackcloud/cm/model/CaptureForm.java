package mx.stackcloud.cm.model;

import jakarta.json.Json;
import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonReader;
import jakarta.json.JsonValue;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.io.StringReader;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class CaptureForm implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(CaptureForm.class);

    private static final long serialVersionUID = 1L;

    private long id;
    private int caseId;
    private String jsonForm;
    private String tipoFormulario;
    private int userId;
    private int activo;
    private LocalDateTime fechaRegistro;

    private transient Boolean requiresSearch;

    public boolean isActive() {
        return activo == 1;
    }

    public void setJsonForm(String jsonForm) {
        this.jsonForm = jsonForm;
        this.requiresSearch = null;
    }

    /**
     * Determines whether this form contains search criteria that warrant an automatic search.
     *
     * <p>A search is required when at least one {@link mx.stackcloud.cm.model.ReportBlock}
     * in the stored JSON satisfies any of:
     * <ul>
     *   <li>{@code allUsageReportTypes} is a non-empty array</li>
     *   <li>{@code deviceHistory} is {@code true}</li>
     *   <li>{@code suscriberHistory} is {@code true}</li>
     * </ul>
     *
     * <p>This is the single source of truth for the search-dispatch decision.
     * No other layer should replicate this logic.
     *
     * <p>The stored JSON is a serialized {@code List<ReportBlock>} — a JSON array at the root.
     * If the JSON is null, blank, or structurally corrupt the method returns {@code false}
     * (safe skip, no exception propagated).
     *
     * @return {@code true} if automatic search must be triggered; {@code false} otherwise
     */
    public boolean requiresAutomaticSearch() {
        if (requiresSearch != null) {
            return requiresSearch;
        }
        requiresSearch = computeRequiresSearch();
        return requiresSearch;
    }

    private boolean computeRequiresSearch() {
        if (jsonForm == null || jsonForm.isBlank()) {
            return false;
        }

        try (JsonReader reader = Json.createReader(new StringReader(jsonForm))) {
            JsonArray array = reader.readArray();

            for (JsonValue value : array) {
                if (value.getValueType() != JsonValue.ValueType.OBJECT) {
                    continue;
                }
                JsonObject obj = value.asJsonObject();

                if (obj.containsKey("allUsageReportTypes")) {
                    JsonArray arr = obj.getJsonArray("allUsageReportTypes");
                    if (arr != null && !arr.isEmpty()) {
                        return true;
                    }
                }

                if (obj.getBoolean("deviceHistory", false)) {
                    return true;
                }

                if (obj.getBoolean("suscriberHistory", false)) {
                    return true;
                }
            }

            return false;

        } catch (Exception e) {
            log.warn("Error parsing jsonForm for formId={}. Skipping search.", id, e);
            return false;
        }
    }
}
