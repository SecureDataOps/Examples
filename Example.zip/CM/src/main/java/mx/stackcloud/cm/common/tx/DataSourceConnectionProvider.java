package mx.stackcloud.cm.common.tx;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Abstrae el acceso al DataSource para desacoplar la infraestructura JDBC
 * de las capas de servicio que gestionan transacciones.
 *
 * El Service controla la transacción (commit, rollback, autoCommit).
 * Este componente solo provee la conexión — no toma decisiones sobre ella.
 */
/**
 * Proveedor de conexiones JDBC desde el DataSource configurado en JNDI.
 *
 * No gestiona transacciones ni cierre de recursos; esa responsabilidad
 * corresponde a la capa de servicio.
 */
@Named
@ApplicationScoped
public class DataSourceConnectionProvider {

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    /**
     * Obtiene una conexión del pool.
     *
     * @return conexión activa
     * @throws SQLException si no es posible obtener la conexión
     */
    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}
