package mx.stackcloud.cm.repository;

import java.sql.Connection;
import java.util.Optional;


public interface BitacoraRepository {

 
    void insert(String token, int statusId, long userId, String event);

    
    void insert(Connection conn, long caseId, int statusId, long userId, String event);

    
    Optional<Integer> findPreviousStatusBeforePending(long caseId, int pendingId);
}
