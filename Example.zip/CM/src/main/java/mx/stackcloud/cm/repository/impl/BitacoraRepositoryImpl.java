package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.repository.BitacoraRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * Implementación del repositorio de histórico de estados (DEV_CASOS_HIST).
 *
 * Esta tabla es append-only. Cada cambio de estado confirmado genera
 * exactamente un INSERT. Nunca se realizan UPDATE ni DELETE sobre ella.
 *
 * Patrón de implementación:
 * El método sin Connection abre el suyo propio y delega en el método con Connection.
 * El repositorio NUNCA cierra una Connection que recibió externamente.
 *
 * INVARIANTE: insert() solo debe llamarse después de que el UPDATE en
 * DEV_CASOS haya afectado 1 fila. Esta responsabilidad pertenece
 * a {@code CaseService.changeStatusTransactional()}.
 */
@Named
@ApplicationScoped
public class BitacoraRepositoryImpl implements BitacoraRepository {

    private static final Logger log = LoggerFactory.getLogger(BitacoraRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    /**
     * Para uso no transaccional: localiza el caso mediante id_token
     * haciendo JOIN con DEV_SOLICITUD y copia todos sus campos a DEV_CASOS_HIST.
     */
    private static final String SQL_INSERT_BY_TOKEN = """
            INSERT INTO APPS.DEV_CASOS_HIST (
                id_caso,
                id_solicitud,
                id_vnc,
                id_tipo,
                id_estatus,
                ID_USUARIO_CREACION,
                evento,
                FECHA_ESTATUS,
                FECHA_REGISTRO
            )
            SELECT
                c.id_caso,
                c.id_solicitud,
                c.id_vnc,
                c.id_tipo,
                ?,
                ?,
                ?,
                SYSDATE,
                SYSDATE
            FROM APPS.DEV_CASOS c
            JOIN APPS.DEV_SOLICITUD s ON c.id_solicitud = s.id_solicitud
            WHERE s.id_token = ?
            """;

    /**
     * Para uso transaccional: copia todos los campos del caso directamente
     * desde DEV_CASOS usando id_caso dentro de la misma transacción.
     *
     * El SELECT lee el registro ya actualizado por el UPDATE precedente,
     * garantizando consistencia sin parámetros adicionales.
     */
    private static final String SQL_INSERT_BY_CASE_ID = """
            INSERT INTO APPS.DEV_CASOS_HIST (
                id_caso,
                id_solicitud,
                id_vnc,
                id_tipo,
                id_estatus,
                ID_USUARIO_CREACION,
                evento,
                FECHA_ESTATUS,
                FECHA_REGISTRO
            )
            SELECT
                c.id_caso,
                c.id_solicitud,
                c.id_vnc,
                c.id_tipo,
                ?,
                ?,
                ?,
                SYSDATE,
                SYSDATE
            FROM APPS.DEV_CASOS c
            WHERE c.id_caso = ?
            """;

    private static final String SQL_FIND_PREV_STATUS = """
            SELECT id_estatus
            FROM APPS.DEV_CASOS_HIST
            WHERE id_caso     = ?
              AND id_estatus  != ?
            ORDER BY FECHA_ESTATUS DESC NULLS LAST
            FETCH FIRST 1 ROW ONLY
            """;

    // ── Método sin Connection ─────────────────────────────────────────────────

    /**
     * {@inheritDoc}
     *
     * <p>Lanza {@link RuntimeException} si la inserción falla.
     */
    @Override
    public void insert(String token, int statusId, long userId, String event) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_BY_TOKEN)) {

            stmt.setInt(1, statusId);
            stmt.setLong(2, userId);
            stmt.setString(3, event);
            stmt.setString(4, token);
            stmt.executeUpdate();

            log.info("DEV_CASOS_HIST — INSERT OK: token={} statusId={} event={}", token, statusId, event);

        } catch (SQLException e) {
            log.error("DEV_CASOS_HIST — INSERT FAILED: token={} statusId={} event={} causa={}",
                    token, statusId, event, e.getMessage());
            throw new RuntimeException("Error al registrar historial de estado", e);
        }
    }

    // ── Método con Connection ─────────────────────────────────────────────────

    /**
     * {@inheritDoc}
     *
     * <p>Usa try-with-resources solo para PreparedStatement.
     * La Connection no se cierra — la gestiona el llamador.
     * Lanza {@link RuntimeException} ante cualquier error SQL para que el llamador
     * ejecute rollback dentro de la misma transacción.
     */
    @Override
    public void insert(Connection conn, long caseId, int statusId, long userId, String event) {
        try (PreparedStatement stmt = conn.prepareStatement(SQL_INSERT_BY_CASE_ID)) {

            stmt.setInt(1, statusId);
            stmt.setLong(2, userId);
            stmt.setString(3, event);
            stmt.setLong(4, caseId);

            int inserted = stmt.executeUpdate();

            // El SELECT ... FROM DEV_CASOS WHERE id_caso=? devuelve 0 filas
            // si el caso no existe. Eso produciría un INSERT silencioso vacío — fallo duro.
            if (inserted != 1) {
                throw new IllegalStateException(
                        "DEV_CASOS_HIST — INSERT afecto " + inserted + " filas (esperado 1)."
                        + " caseId=" + caseId
                        + " statusId=" + statusId
                        + " event=" + event
                );
            }

            log.info("DEV_CASOS_HIST — INSERT OK: caseId={} statusId={} event={}", caseId, statusId, event);

        } catch (SQLException e) {
            log.error("DEV_CASOS_HIST — INSERT FAILED: caseId={} statusId={} event={} causa={}",
                    caseId, statusId, event, e.getMessage());
            throw new RuntimeException(
                    "Error al registrar historial de estado. caseId=" + caseId
                    + " statusId=" + statusId
                    + " event=" + event,
                    e
            );
        }
    }

    // ── Consulta de estado previo ─────────────────────────────────────────────

    /** {@inheritDoc} */
    @Override
    public Optional<Integer> findPreviousStatusBeforePending(long caseId, int pendingId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_PREV_STATUS)) {

            stmt.setLong(1, caseId);
            stmt.setInt(2, pendingId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(rs.getInt(1));
                }
            }

            log.warn("DEV_CASOS_HIST — no se encontró estado previo a PENDING: caseId={}", caseId);
            return Optional.empty();

        } catch (SQLException e) {
            log.error("DEV_CASOS_HIST — findPreviousStatusBeforePending FAILED: caseId={} causa={}",
                    caseId, e.getMessage());
            throw new RuntimeException(
                    "Error al buscar estado previo en historial. caseId=" + caseId, e);
        }
    }
}
