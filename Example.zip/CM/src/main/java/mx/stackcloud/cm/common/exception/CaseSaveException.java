package mx.stackcloud.cm.common.exception;

/**
 * Excepción de negocio utilizada cuando ocurre un error al guardar un caso.
 *
 * Indica que la operación no pudo completarse debido a una validación o
 * regla de negocio incumplida, no a un error técnico.
 *
 * Debe ser manejada en la capa de presentación para mostrar un mensaje al usuario.
 */
public class CaseSaveException extends Exception {

    /**
     * Crea la excepción con un mensaje descriptivo.
     *
     * @param message descripción del error de negocio
     */
    public CaseSaveException(String message) {
        super(message);
    }

}
