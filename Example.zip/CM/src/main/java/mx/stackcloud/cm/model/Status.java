package mx.stackcloud.cm.model;

import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Enum que representa los diferentes estados de una entidad dentro del sistema.
 *
 * <p>Cada estado contiene:
 * <ul>
 *   <li>Un identificador único ({@code id})</li>
 *   <li>Una etiqueta descriptiva ({@code label})</li>
 * </ul>
 *
 * <p>Además, define:
 * <ul>
 *   <li>Reglas de negocio</li>
 *   <li>Validación de transiciones entre estados</li>
 *   <li>Conversión desde valores de base de datos</li>
 * </ul>
 *
 * <p>Se incluye un estado {@code UNKNOWN} para manejar valores inválidos o desconocidos.
 */
@Getter
public enum Status {

    NEW(1, "Nuevo"),
    READ(2, "Leído"),
    CAPTURE(3, "Captura"),
    IN_PROGRESS(4, "Proceso"),
    READY(5, "Listo"),
    PENDING(6, "Pendiente"),
    RESOLVED(7, "Resuelto"),
    CLOSED(8, "Cerrado"),
    CANCELED(9, "Cancelado"),
    REOPENED(10, "Reapertura"),
    MULTIPLE(11, "Multiples"),
    UNKNOWN(-1, "N/D");

    private static final Logger log = LoggerFactory.getLogger(Status.class);

    /**
     * Identificador único del estado
     */
    private final int id;
    /**
     * Etiqueta descriptiva del estado
     */
    private final String label;

    /**
     * Constructor del enum.
     *
     * @param id    identificador único del estado
     * @param label descripción del estado
     */
    Status(int id, String label) {
        this.id = id;
        this.label = label;
    }

    /**
     * Mapa cacheado para búsqueda eficiente de estados por ID.
     */
    private static final Map<Integer, Status> BY_ID =
            Arrays.stream(values()).collect(Collectors.toMap(Status::getId, s -> s));

    /**
     * Obtiene un estado a partir de su identificador.
     *
     * @param id identificador del estado
     * @return el estado correspondiente o {@link #UNKNOWN} si no existe o es null
     */
    public static Status fromId(Integer id) {
        if (id == null) {
            log.warn("Null status id from DB");
            return UNKNOWN;
        }
        return BY_ID.getOrDefault(id, UNKNOWN);
    }

    /**
     * Indica si el estado permite edición.
     *
     * @return {@code true} si el estado es NEW, READ o CAPTURE; {@code false} en otro caso
     */
    public boolean isEditable() {
        return this == NEW || this == READ || this == CAPTURE;
    }

    /**
     * Indica si el estado requiere generar un nuevo formulario.
     *
     * @return {@code true} si el estado es ANALYSIS o STOPPED
     */
    public boolean requiresNewForm() {
        return this == IN_PROGRESS;
    }

    /**
     * Obtiene la severidad asociada al estado.
     *
     * <p>Útil para representación visual (UI) o clasificación lógica.
     *
     * @return nivel de severidad: info, warning, primary, success, danger o secondary
     */
    public String getSeverity() {
        return switch (this) {
            case NEW -> "info";
            case READ -> "secondary";
            case CAPTURE -> "info";
            case IN_PROGRESS, PENDING -> "warning";
            case READY -> "primary";
            case RESOLVED, CLOSED -> "success";
            case CANCELED -> "danger";
            case REOPENED -> "primary";
            case MULTIPLE -> "primary";
            default -> "secondary";
        };
    }

    /**
     * Devuelve el conjunto de estados permitidos como siguiente transición.
     *
     * @return conjunto de estados válidos a los que se puede transicionar
     */
    public Set<Status> allowedNext() {
        return switch (this) {
            case NEW -> EnumSet.of(READ, CANCELED);

            case READ -> EnumSet.of(CAPTURE, CANCELED);

            case CAPTURE -> EnumSet.of(IN_PROGRESS, PENDING, CANCELED);

            case IN_PROGRESS -> EnumSet.of(READY, PENDING, CANCELED);

            case READY -> EnumSet.of(CLOSED, PENDING, CANCELED);

            case RESOLVED -> EnumSet.of(CLOSED, REOPENED, CANCELED);

            case CLOSED -> EnumSet.of(REOPENED);

            case REOPENED -> EnumSet.of(IN_PROGRESS, CAPTURE, CANCELED);

            // PENDING puede regresar a cualquier estado no terminal previo
            case PENDING -> EnumSet.noneOf(Status.class);

            case CANCELED -> EnumSet.noneOf(Status.class);

            case MULTIPLE -> EnumSet.noneOf(Status.class);

            case UNKNOWN -> EnumSet.allOf(Status.class);
        };
    }


    /**
     * Valida si es posible realizar una transición hacia otro estado.
     *
     * @param next estado destino
     * @return {@code true} si la transición es válida; {@code false} en caso contrario
     */
    public boolean canTransitionTo(Status next) {
        if (next == null || this == next) return false;
        return allowedNext().contains(next);
    }

}