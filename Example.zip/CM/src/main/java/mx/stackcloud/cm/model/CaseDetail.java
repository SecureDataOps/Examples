package mx.stackcloud.cm.model;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa el detalle de un caso dentro del sistema.
 *
 * <p>Contiene la información principal del caso, incluyendo su identificación,
 * estado, fechas relevantes, datos del correo asociado y archivos adjuntos.
 *
 * <p>La clase mantiene tanto el identificador crudo del estado
 * ({@code idStatusCase}), usado para persistencia e integración, como una
 * representación tipada ({@link Status}) para la lógica de negocio.
 *
 * <p>Para reglas de negocio debe preferirse {@link #getStatusEnum()} en lugar de
 * evaluar directamente {@code idStatusCase}.
 */
@Getter
@Setter
@NoArgsConstructor
public class CaseDetail implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    /** Identificador único del caso. */
    private int id;

    /** Token o referencia pública del caso. */
    private String token;

    /**
     * Identificador del estado del caso tal como se obtiene desde la base de datos.
     *
     * <p>Este campo se conserva por compatibilidad con el modelo de persistencia
     * y con código legado. No debe usarse directamente en lógica de negocio;
     * para ello debe emplearse {@link #getStatusEnum()}.
     *
     * <p>El setter es manual para invalidar la caché interna del estado tipado
     * cuando el valor cambia.
     */
    @Setter(AccessLevel.NONE)
    private int idStatusCase;

    /** Identificador del estado de la solicitud relacionada con el caso. */
    private int idStatusRequest;

    /** Tipo de solicitud asociada al caso. */
    private String requestType;

    /** Prioridad asignada al caso. */
    private String priority;

    /** Fecha y hora del último cambio de estado del caso. */
    private LocalDateTime statusDate;

    /** Fecha y hora en que el caso fue registrado. */
    private LocalDateTime registrationDate;

    /** Asunto del correo asociado al caso. */
    private String emailSubject;

    /** Dirección o identificador del remitente del correo asociado. */
    private String emailFrom;

    /** Contenido del correo asociado al caso. */
    private String emailBody;

    /**
     * Adjuntos relacionados con el caso.
     *
     * <p>Se inicializa con una lista vacía para evitar validaciones nulas
     * durante su uso.
     */
    private List<CaseAttachment> attachments = new ArrayList<>();

    /**
     * Caché transitoria de la representación tipada del estado del caso.
     *
     * <p>Se calcula bajo demanda a partir de {@link #idStatusCase}. Al ser
     * {@code transient}, no se serializa. Su acceso debe realizarse únicamente
     * mediante {@link #getStatusEnum()}.
     */
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private transient Status statusEnum;

    /**
     * Actualiza el identificador crudo del estado del caso.
     *
     * <p>Al cambiar este valor, se invalida la caché interna del estado tipado
     * para garantizar que la próxima llamada a {@link #getStatusEnum()} refleje
     * el nuevo estado.
     *
     * @param idStatusCase nuevo identificador del estado del caso
     */
    public void setIdStatusCase(int idStatusCase) {
        this.idStatusCase = idStatusCase;
        this.statusEnum = null;
    }

    /**
     * Devuelve la representación tipada del estado actual del caso.
     *
     * <p>El valor se resuelve a partir de {@link #idStatusCase} mediante
     * {@link Status#fromId(int)} y se almacena en caché para evitar
     * conversiones repetidas.
     *
     * <p>Si el identificador del estado cambia mediante
     * {@link #setIdStatusCase(int)}, la caché se invalida automáticamente.
     *
     * @return estado tipado correspondiente al identificador actual
     */
    public Status getStatusEnum() {
        if (statusEnum == null) {
            statusEnum = Status.fromId(idStatusCase);
        }
        return statusEnum;
    }
}
