package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum StandardReportType {
    HOLDER_NAMES("Nombre(s) (Titular)"),
    COMPANY_NAME("Nombre Compañia"),
    ADDRESS("Dirección (Domicilio)"),
    ACTIVATION_DATE("Fecha Activación"),
    IMSI("IMSI"),
    IMEI("IMEI"),
    MSISDN("MSISDN"),
    ICCID("ICCID"),
    PLAN_TYPE("Prepago o Postpago"),
    DISTRIBUTOR_NAME("Nombre del Distribuidor"),
    DISTRIBUTOR_ADDRESS("Dirección del Distribuidor de Venta"),
    DEVICE_SPECS("Características Técnicas del Dispositivo"),
    IMSI_SECONDARY("IMSI ");

    private final String label;

    StandardReportType(String label) {
        this.label = label;
    }
}
