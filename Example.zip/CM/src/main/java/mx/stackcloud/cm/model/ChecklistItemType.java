package mx.stackcloud.cm.model;

/**
 * Tipo de ítem dentro del checklist de validación READY.
 * AUTO se valida contra el resultado del middleware.
 * MANUAL requiere selección explícita del usuario.
 */
public enum ChecklistItemType {
    AUTO,
    MANUAL
}
