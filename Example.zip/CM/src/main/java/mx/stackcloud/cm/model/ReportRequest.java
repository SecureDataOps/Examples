package mx.stackcloud.cm.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

/**
 * Represents the entire report request payload saved by the user.
 */
public class ReportRequest implements Serializable {
    private UUID id;
    private LocalDateTime date;
    private List<ReportBlock> blocks;

    /**
     * Default constructor for ReportRequest.
     */
    public ReportRequest() {
    }

    /**
     * Constructs a request with a specified list of report blocks.
     *
     * @param blocks A list of ReportBlock objects configured by the user.
     */
    public ReportRequest(List<ReportBlock> blocks) {
        this.id = UUID.randomUUID();
        this.date = LocalDateTime.now(ZoneId.of("America/Mexico_City"));
        this.blocks = blocks;
    }

    /**
     * Gets the unique identifier of the report request.
     *
     * @return The UUID of the request.
     */
    public UUID getId() {
        return id;
    }

    /**
     * Sets the unique identifier for the request.
     *
     * @param id The UUID to be set.
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Gets the date and time when the request was generated.
     *
     * @return The LocalDateTime of the request generation.
     */
    public LocalDateTime getDate() {
        return date;
    }

    /**
     * Sets the date and time the request was generated.
     *
     * @param date The LocalDateTime to be set.
     */
    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    /**
     * Gets the list of defined report blocks.
     *
     * @return The list of ReportBlock objects.
     */
    public List<ReportBlock> getBlocks() {
        return blocks;
    }

    /**
     * Sets the report blocks for this request.
     *
     * @param blocks The list of ReportBlock objects to associate.
     */
    public void setBlocks(List<ReportBlock> blocks) {
        this.blocks = blocks;
    }
}
