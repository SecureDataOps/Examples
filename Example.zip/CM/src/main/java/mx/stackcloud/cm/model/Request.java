package mx.stackcloud.cm.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Request {
    String token;
    String typeRequest;
    int idMail;
    Status statusRequest;
    int idCase;
    String typeCase;
    String registrationDate;
    String priority;
    Status statusCase;
    String operationUser;
    String statusDate;
}
