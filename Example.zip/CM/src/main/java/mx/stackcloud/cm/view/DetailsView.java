package mx.stackcloud.cm.view;

import mx.stackcloud.cm.common.util.FormSummaryBuilder;
import mx.stackcloud.cm.model.*;
import mx.stackcloud.cm.service.CaseService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mx.stackcloud.cm.common.exception.CaseSaveException;

import org.primefaces.model.DefaultTreeNode;
import org.primefaces.model.TreeNode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Named
@ViewScoped
public class DetailsView implements Serializable {

    private static final Logger log = LoggerFactory.getLogger(DetailsView.class);
    private static final String DEMO_FILE_PATH = "C:\\temp\\demo1.pdf";

    @Serial
    private static final long serialVersionUID = 1L;

    @Inject
    CaseService caseService;

    @Getter
    private CaseDetail caseDetail;

    @Getter
    @Setter
    private RequestAddendum requestAddendum;

    @Getter
    @Setter
    private boolean editingAddendum = true;

    @Getter
    @Setter
    private boolean hasAddendum = false;

    @Getter
    @Setter
    private int caseId;

    @Getter
    @Setter
    private String typeViewData;

    @Getter
    @Setter
    private String requestId;

    //Forms
    @Getter
    @Setter
    private List<ReportBlock> reportBlocks;


    @Getter
    private boolean editingSherlock = false;

    /**
     * Set to true after a successful saveCase to prevent duplicate saves.
     */
    @Getter
    private boolean caseSaved = false;

    // ── Form versioning ────────────────────────────────────────────────────────

    /**
     * Active version (activo=1) loaded on init. null if none exists.
     */
    @Getter
    private CaptureForm activeForm;

    /**
     * All versions for the current case, newest first.
     */
    @Getter
    private List<CaptureForm> formHistory = Collections.emptyList();

    /**
     * Version selected in the history panel to view in the dialog.
     */
    @Getter
    @Setter
    private CaptureForm selectedHistoryForm;

    /**
     * Report blocks for the read-only history dialog (separate from live form).
     */
    @Getter
    private List<ReportBlock> historyReportBlocks = Collections.emptyList();

    /**
     * Human-readable summary of the form version selected in the history dialog.
     */
    @Getter
    private FormSummary selectedFormSummary;

    /**
     * Human-readable summary of the version immediately preceding {@link #selectedHistoryForm}.
     */
    @Getter
    private FormSummary previousFormSummary;

    /**
     * Diff lines produced by {@link #compareWithPreviousVersion()}.
     */
    @Getter
    private List<String> formDiff = Collections.emptyList();

    /**
     * True while the diff panel is visible inside the history dialog.
     */
    @Getter
    private boolean showingDiff = false;

    /**
     * True when the case status allows editing the current active form.
     */
    @Getter
    private boolean formEditable = false;

    /**
     * True when the case status requires a brand-new form version on save.
     */
    @Getter
    private boolean requiresNewFormVersion = false;

    // ── Checklist READY ───────────────────────────────────────────────────────

    /**
     * Lista de grupos del checklist construida desde JSON_CAPTURA.
     * Un grupo por cada criterio de búsqueda del formulario activo.
     * Vacía si no existe formulario activo o el caso no aplica.
     */
    @Getter
    private List<ChecklistGroup> checklistGroups = Collections.emptyList();

    // ── Search tree ────────────────────────────────────────────────────────────

    /**
     * Root node of the search hierarchy tree rendered by {@code p:tree}.
     * The root itself is invisible (not rendered); its children are the nivel-1 searches.
     * Rebuilt every time {@link #loadBusquedaTree()} is called.
     */
    @Getter
    private TreeNode<Search> busquedaTree;

    //Render
    @Getter
    private boolean rndModuleRequest = false;

    @Getter
    private boolean rndModuleCase = false;

    @Getter
    private List<CaseAttachment> caseAttachments;

    @Getter
    @Setter
    private String selectedFile;

    @PostConstruct
    public void init() {
        caseId = 1;
        requestAddendum = new RequestAddendum();
        validateViewData();

        // Evento: apertura de la vista → NEW → READ (idempotente si ya está en READ)
        caseService.openCaseIfNeeded(caseId, resolveUserId());

        loadCaseDetail();
        loadComplemento();
        loadAttachments();
        loadFormState();
        loadBusquedaTree();
        loadChecklist();

    }

    // REFACTOR PARCIAL — ENFOCADO EN:
// - Separación Addendum vs Sherlock
// - Eliminación de lógica duplicada
// - Centralización de reglas de UI
// - Reducción de responsabilidades del View


// =========================
// 🔹 NUEVAS REGLAS CENTRALIZADAS
// =========================

    private boolean isAddendumEditable() {
        return caseDetail != null
                && isCaseEditable()
                && caseDetail.getStatusEnum() != Status.PENDING;
    }

    private boolean isSherlockEditable() {
        return caseDetail != null
                && formEditable
                && isCaseEditable();
    }

    private boolean isSherlockEditingEnabled() {
        return editingSherlock && isSherlockEditable();
    }


// =========================
// 🔹 BOTONES (SIN DUPLICACIÓN)
// =========================

    public boolean isShowEditButton() {
        return isSherlockEditable() && !editingSherlock;
    }

    public boolean isShowSaveButton() {
        return isSherlockEditingEnabled();
    }

    public boolean isShowCancelEditButton() {
        return isSherlockEditingEnabled();
    }

    public boolean isShowNewFormButton() {
        if (caseDetail == null) return false;

        return !editingSherlock
                && isSherlockEditable()
                && caseDetail.getStatusEnum().requiresNewForm();
    }


// =========================
// 🔹 ADDENDUM (AISLADO)
// =========================

    public boolean isShowEditAddendumButton() {
        return isAddendumEditable() && !editingAddendum;
    }

    public boolean isShowSaveAddendumButton() {
        return editingAddendum && isAddendumEditable();
    }

    public boolean isShowCancelAddendumButton() {
        return editingAddendum && isAddendumEditable();
    }


// =========================
// 🔹 LOAD FORM STATE (SIMPLIFICADO)
// =========================

    private void loadFormState() {
        clear();

        if (caseId == 0) return;

        formHistory = caseService.findFormHistory(caseId);

        Status status = caseDetail != null
                ? caseDetail.getStatusEnum()
                : Status.UNKNOWN;

        formEditable = status.isEditable();
        requiresNewFormVersion = status.requiresNewForm();

        Optional<CaptureForm> active = caseService.findActiveForm(caseId);

        applySherlockState(status, active);
    }


    private void applySherlockState(Status status, Optional<CaptureForm> active) {

        boolean isReadOnly = (status == Status.CANCELED || status == Status.CLOSED);
        boolean isPending = (status == Status.PENDING);

        if (active.isPresent()) {
            activeForm = active.get();
            editingSherlock = false;

            restoreBlocksFromJson(activeForm.getJsonForm());


        } else {
            activeForm = null;

            // Primera captura
            editingSherlock = (status == Status.READ);
        }

        // Bloqueo global SOLO para Sherlock
        if (isReadOnly || isPending) {
            editingSherlock = false;
        }
    }


// =========================
// 🔹 ADDENDUM LOAD (SIN EFECTOS CRUZADOS)
// =========================

    private void loadComplemento() {
        String token = caseDetail.getToken();

        if (token == null || token.isBlank() || token.equals("—")) {
            hasAddendum = false;
            editingAddendum = true;
            return;
        }

        Optional<String> stored = caseService.findComplemento(token);

        if (stored.isPresent()) {
            hasAddendum = true;
            requestAddendum = deserializeAddendum(stored.get());
            editingAddendum = false;
        } else {
            hasAddendum = false;
            editingAddendum = true;
        }

        // 🔥 SOLO aplicar reglas propias de Addendum
        if (!isAddendumEditable()) {
            editingAddendum = false;
        }
    }


// =========================
// 🔹 ACCIONES SHERLOCK (CONTROLADAS)
// =========================

    public void enableFormEdit() {
        if (!isSherlockEditable()) return;

        editingSherlock = true;
        caseSaved = false;
    }

    public void cancelSherlockEdit() {
        editingSherlock = false;
        caseSaved = false;

        if (activeForm != null) {
            restoreBlocksFromJson(activeForm.getJsonForm());

        } else {
            clear();
        }
    }

    public void startNewForm() {
        if (!requiresNewFormVersion || !isSherlockEditable()) return;

        clear();
        editingSherlock = true;
        caseSaved = false;
    }

    private boolean validateFormBlocks() {
        for (int i = 0; i < reportBlocks.size(); i++) {
            ReportBlock b = reportBlocks.get(i);
            int blockNum = i + 1;

            if (b.getStartDate() == null || b.getEndDate() == null) {
                error("Bloque " + blockNum + ": Debe especificar Fecha Inicio y Fecha Fin.");
                return false;
            }
            if (b.getStartDate().isAfter(b.getEndDate())) {
                error("Bloque " + blockNum + ": La Fecha Inicio no puede ser posterior a la Fecha Fin.");
                return false;
            }

            List<CriteriaValue> criteria = b.getCriteria();
            for (int j = 0; j < criteria.size(); j++) {
                CriteriaValue c = criteria.get(j);
                int critNum = j + 1;
                CriteriaType cType = c.getCriteriaType();

                if (cType == null) {
                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Debe seleccionar un Tipo de Criterio.");
                    return false;
                }

                String v = c.getValue() == null ? "" : c.getValue().trim();
                c.setValue(v);

                if (v.isEmpty()) {
                    error("Bloque " + blockNum + ", Criterio " + critNum + ": El valor no puede estar vacío.");
                    return false;
                }

                if (v.length() < cType.getMinLength() || v.length() > cType.getMaxLength()) {
                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Mínimo " + cType.getMinLength() + " caracteres.");
                    return false;
                }

                if (!cType.isValid(v)) {
                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Formato inválido para " + cType.name() + ".");
                    return false;
                }
            }

            if ((b.getStandardReportTypes() == null || b.getStandardReportTypes().isEmpty()) &&
                    (b.getOnDemandReportTypes() == null || b.getOnDemandReportTypes().isEmpty()) &&
                    (b.getCdrsReportTypes() == null || b.getCdrsReportTypes().isEmpty()) &&
                    (b.getCdrsRoamingReportTypes() == null || b.getCdrsRoamingReportTypes().isEmpty()) &&
                    !b.isDeviceHistory() && !b.isSuscriberHistory()) {
                error("Bloque " + blockNum + ": seleccione al menos un reporte.");
                return false;
            }
        }
        return true;
    }


    public boolean isCaseEditable() {
        if (caseDetail == null) return false;

        Status s = caseDetail.getStatusEnum();
        return s != Status.CANCELED && s != Status.CLOSED;
    }


    private void loadCaseDetail() {
        int idToLoad = caseId != 0 ? caseId : 1;
        caseDetail = caseService.findCaseById(idToLoad).orElseGet(() -> {
            CaseDetail empty = new CaseDetail();
            empty.setToken("—");
            empty.setRequestType("—");
            empty.setIdStatusCase(0);
            empty.setIdStatusRequest(0);
            empty.setPriority("—");
            return empty;
        });
    }

    public boolean isShowCancelButton() {
        return caseDetail != null
                && caseDetail.getStatusEnum() == Status.CAPTURE;
    }


    private void loadAttachments() {
        List<CaseAttachment> loaded = caseDetail.getAttachments();
        if (loaded != null && !loaded.isEmpty()) {
            caseAttachments = loaded;
        } else {
            CaseAttachment demo = new CaseAttachment();
            demo.setFilename("demo1.pdf");
            demo.setPath(DEMO_FILE_PATH);
            caseAttachments = new ArrayList<>();
            caseAttachments.add(demo);
        }
        selectedFile = caseAttachments.get(0).getPath();
    }


    public void changePdfView() {
        log.debug("PDF view changed to: {}", selectedFile);
    }

    public void validateViewData() {
        var params = FacesContext.getCurrentInstance()
                .getExternalContext()
                .getRequestParameterMap();

        typeViewData = params.get("viewData");

        String pReq = params.get("idRequest");
        if (pReq != null && !pReq.isBlank()) {
            requestId = pReq;
        }

        String pCase = params.get("idCase");
        if (pCase != null && !pCase.isBlank()) {
            caseId = Integer.parseInt(pCase);
        }

        if (typeViewData != null) {
            if (typeViewData.trim().equals("Request")) {
                if (requestId != null && !requestId.trim().isEmpty()) {
                    log.debug("View mode: Request id={}", requestId);
                    rndModuleRequest = true;
                }
            } else if (typeViewData.trim().equals("Case")) {
                if (caseId != 0) {
                    log.debug("View mode: Case id={}", caseId);
                    rndModuleCase = true;
                }
            } else {
                log.warn("Unknown viewData value: {}", typeViewData);
            }
        }
    }

    public void saveAddendum() {
        String token = caseDetail.getToken();
        if (token == null || token.isBlank() || token.equals("—")) {
            error("No es posible guardar: el token del caso no está disponible.");
            return;
        }

        String json = serializeAddendum();
        if (json == null) return;

        int userId = (int) resolveUserId();
        if (!hasAddendum) {
            if (caseService.saveComplemento(token, json, userId)) {
                hasAddendum = true;
                editingAddendum = false;
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Complemento guardado correctamente."));
            } else {
                error("No fue posible guardar el complemento. Intente de nuevo.");
            }
        } else {
            if (caseService.updateComplemento(token, json, userId)) {
                editingAddendum = false;
                FacesContext.getCurrentInstance().addMessage(null,
                        new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito", "Complemento actualizado correctamente."));
            } else {
                error("No fue posible actualizar el complemento. Intente de nuevo.");
            }
        }
    }

    public void editAddendum() {
        editingAddendum = true;
    }

    public void cancelEditAddendum() {
        editingAddendum = false;
        String token = caseDetail.getToken();
        caseService.findComplemento(token)
                .ifPresent(json -> requestAddendum = deserializeAddendum(json));
    }

    public boolean isBusquedaTreeRefreshEnabled() {
        if (caseDetail == null) return false;

        Status s = caseDetail.getStatusEnum();

        return s != Status.CLOSED
                && s != Status.CANCELED
                && s != Status.UNKNOWN;
    }

    // ── PDF actions ───────────────────────────────────────────────────────────

    /**
     * Streams {@link #selectedFile} to the browser as a downloadable file.
     * Uses a non-AJAX response — the XHTML button must declare {@code ajax="false"}.
     * No backend state is modified.
     */
    public void downloadPdf() {
        if (selectedFile == null || selectedFile.isBlank()) {
            error("No hay documento seleccionado para descargar.");
            return;
        }

        File file = new File(selectedFile);
        if (!file.exists() || !file.isFile()) {
            log.warn("downloadPdf: file not found at path={}", selectedFile);
            error("El archivo seleccionado no está disponible en el servidor.");
            return;
        }

        FacesContext fc = FacesContext.getCurrentInstance();
        jakarta.faces.context.ExternalContext ec = fc.getExternalContext();

        ec.responseReset();
        ec.setResponseContentType("application/pdf");
        ec.setResponseContentLength((int) file.length());
        ec.setResponseHeader("Content-Disposition",
                "attachment; filename=\"" + file.getName() + "\"");

        try (InputStream in = new FileInputStream(file);
             OutputStream out = ec.getResponseOutputStream()) {
            in.transferTo(out);
        } catch (IOException e) {
            log.error("downloadPdf failed for path={}: {}", selectedFile, e.getMessage());
            // Response is already committed — cannot send a Faces message here
            return;
        }

        fc.responseComplete();
    }

    /**
     * Carga el checklist de validación desde el formulario activo del caso.
     * Si no existe formulario o el caso no aplica, deja la lista vacía.
     */
    private void loadChecklist() {
        if (caseId == 0) {
            checklistGroups = Collections.emptyList();
            return;
        }
        try {
            checklistGroups = caseService.buildChecklist(caseId);
        } catch (CaseSaveException e) {
            log.debug("loadChecklist: sin formulario activo para checklist — caseId={}", caseId);
            checklistGroups = Collections.emptyList();
        } catch (Exception e) {
            log.warn("loadChecklist: error inesperado — caseId={}", caseId, e);
            checklistGroups = Collections.emptyList();
        }
    }

    // ── Acciones de estado ────────────────────────────────────────────────────

    /**
     * Cancela el caso. Delega al servicio; no contiene lógica de negocio.
     */
    public void cancelCase() {
        try {
            caseService.cancelCase(caseId, resolveUserId());
            loadCaseDetail();
            loadFormState();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Caso cancelado",
                            "El caso ha sido cancelado."));
        } catch (Exception e) {
            log.error("cancelCase: error — caseId={}", caseId, e);
            error("No fue posible cancelar el caso. Intente de nuevo.");
        }
    }

    /**
     * Marca el caso como pendiente. Delega al servicio; no contiene lógica de negocio.
     */
    public void markPendingCase() {
        try {
            caseService.markPending(caseId, resolveUserId());
            loadCaseDetail();
            loadFormState();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Caso pendiente",
                            "El caso ha sido marcado como pendiente."));
        } catch (Exception e) {
            log.error("markPendingCase: error — caseId={}", caseId, e);
            error("No fue posible marcar el caso como pendiente. Intente de nuevo.");
        }
    }

    /**
     * Reanuda el caso desde estado pendiente. Delega al servicio; no contiene lógica de negocio.
     */
    public void resumeCase() {
        try {
            caseService.resumeFromPending(caseId, resolveUserId());
            loadCaseDetail();
            loadFormState();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Caso reanudado",
                            "El caso ha sido reanudado."));
        } catch (Exception e) {
            log.error("resumeCase: error — caseId={}", caseId, e);
            error("No fue posible reanudar el caso. Intente de nuevo.");
        }
    }

    // ── Helpers de renderizado para la UI ─────────────────────────────────────

    /**
     * Indica si los botones de cancelar y pendiente deben estar visibles.
     * Solo aplica cuando el caso no está en un estado terminal ni en PENDING.
     */
    public boolean isShowCancelAndPendingButtons() {
        if (caseDetail == null) return false;
        Status s = caseDetail.getStatusEnum();
        return s != Status.CANCELED && s != Status.CLOSED && s != Status.PENDING;
    }

    /**
     * Indica si el botón de reanudar debe estar visible.
     * Solo aplica cuando el caso está en PENDING.
     */
    public boolean isShowResumeButton() {
        return caseDetail != null
                && caseDetail.getStatusEnum() == Status.PENDING;
    }

    // ── Checklist READY — soporte UI y acción ────────────────────────────────

    /**
     * Retorna las opciones disponibles para selección manual en el checklist.
     */
    public List<ManualResult> getManualOptions() {
        return Arrays.asList(ManualResult.values());
    }

    /**
     * Retorna la severidad de PrimeFaces correspondiente al status de un target AUTO.
     * Usado por {@code p:tag} en el tab Checklist para colorear el resultado.
     *
     * @param status estado del target; null si aún no fue enriquecido
     * @return "success", "info", "danger" o "secondary"
     */
    public String getSeverity(TargetStatus status) {
        if (status == null) return "secondary";
        return switch (status) {
            case RESULTS_AVAILABLE -> "success";
            case NO_RESULTS_AVAILABLE -> "info";
            case ERROR -> "danger";
        };
    }

    /**
     * Retorna la etiqueta legible del status de un target AUTO para mostrar en UI.
     *
     * @param status estado del target; null si aún no fue enriquecido
     * @return etiqueta en español
     */
    public String getTargetStatusLabel(TargetStatus status) {
        if (status == null) return "Pendiente";
        return switch (status) {
            case RESULTS_AVAILABLE -> "Con resultados";
            case NO_RESULTS_AVAILABLE -> "Sin resultados";
            case ERROR -> "Error";
        };
    }

    /**
     * Indica si el checklist está en modo solo lectura.
     * Los ítems MANUAL solo son editables cuando el caso está en IN_PROGRESS.
     */
    public boolean isReadOnly() {
        if (caseDetail == null) return true;
        return caseDetail.getStatusEnum() != Status.IN_PROGRESS;
    }

    /**
     * Indica si el caso está actualmente en estado IN_PROGRESS.
     * Controla la visibilidad del botón "Tareas Completadas".
     */
    public boolean isInProgress() {
        return caseDetail != null && caseDetail.getStatusEnum() == Status.IN_PROGRESS;
    }

    /**
     * Acción del botón "Tareas Completadas".
     * Recorre los grupos del checklist, recolecta las selecciones manuales con clave compuesta
     * (criteriaType:reportType) y delega la transición IN_PROGRESS → READY al servicio.
     * No contiene lógica de negocio.
     */
    public void markReady() {
        Map<String, ManualResult> selections = new HashMap<>();
        for (ChecklistGroup group : checklistGroups) {
            for (ChecklistItem item : group.getManualItems()) {
                String key = group.getCriteriaType().name() + ":" + item.getReportType();
                selections.put(key, item.getManualResult());
            }
        }

        try {
            caseService.markReady(caseId, selections, resolveUserId());
            loadCaseDetail();
            loadChecklist();
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Caso listo",
                            "El caso ha sido marcado como Listo correctamente."));
        } catch (CaseSaveException e) {
            log.warn("markReady: validación fallida — caseId={} msg={}", caseId, e.getMessage());
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        } catch (Exception e) {
            log.error("markReady: error inesperado — caseId={}", caseId, e);
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error inesperado",
                            "Ocurrió un problema al marcar el caso como Listo."));
        }
    }

    // ── Guardar Caso ──────────────────────────────────────────────────────────

    /**
     * Acción enlazada al botón "Guardar Caso" de la barra de herramientas.
     * Delega toda la validación y el despacho al servicio {@link CaseService#saveCase}.
     * Al tener éxito activa {@code caseSaved=true} para deshabilitar el botón
     * y prevenir guardados duplicados. No contiene lógica de negocio.
     */
    public void saveCase() {

        if (caseSaved) {
            log.warn("Duplicate saveCase prevented for caseId={}", caseId);
            return;
        }

        String token = caseDetail != null ? caseDetail.getToken() : null;
        long userId = resolveUserId();

        log.info("Saving case {} with token {} userId={}", caseId, token, userId);

        try {
            caseService.saveCase(caseId, token, userId);

            //CRÍTICO: refrescar estado real
            loadCaseDetail();

            // recalcular UI
            loadFormState();

            caseSaved = true;

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(
                            FacesMessage.SEVERITY_INFO,
                            "Caso guardado",
                            "El caso fue procesado correctamente."
                    ));

        } catch (CaseSaveException e) {

            log.warn("saveCase rejected for caseId={}: {}", caseId, e.getMessage());

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(
                            FacesMessage.SEVERITY_ERROR,
                            "Error",
                            e.getMessage()
                    ));

        } catch (Exception e) {

            log.error("Unexpected error saving case {}", caseId, e);

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(
                            FacesMessage.SEVERITY_ERROR,
                            "Error inesperado",
                            "Ocurrió un problema al guardar el caso."
                    ));
        }
    }

    /**
     * Resuelve el ID numérico del usuario autenticado desde el principal de seguridad.
     * Mientras no exista un UserRepository que traduzca el nombre a ID numérico se
     * devuelve 1 como valor de respaldo temporal.
     * Reemplazar cuando se integre el módulo de seguridad.
     */
    private long resolveUserId() {
        try {
            java.security.Principal p = FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .getUserPrincipal();
            if (p != null && !p.getName().isBlank()) {
                // TODO: traducir p.getName() a ID numérico via UserRepository
                log.debug("resolveUserId: principal={}", p.getName());
            }
        } catch (Exception e) {
            log.warn("resolveUserId: no se pudo obtener el principal — usando fallback userId=1");
        }
        // TODO: eliminar fallback al integrar UserRepository
        return 1L;
    }


    // ── Search tree ────────────────────────────────────────────────────────────

    /**
     * Loads and rebuilds the search hierarchy tree from the database.
     * Safe to call multiple times — each call replaces the previous tree.
     * A no-op when {@code caseId} is 0.
     */
    public void loadBusquedaTree() {
        busquedaTree = buildBusquedaTree(caseId);
    }

    /**
     * Builds a PrimeFaces {@link TreeNode} hierarchy from a flat ordered list of
     * {@link Search} records returned by the service.
     *
     * <p>The list must be ordered NIVEL ASC, ID ASC (guaranteed by the repository),
     * so every parent is already in the map when its children are processed.
     *
     * <p>Tree structure:
     * <pre>
     *   root (invisible, type="root")
     *   └── nivel-1 busqueda  (type="search")
     *       └── nivel-2 busqueda  (type="search")
     *           └── ...
     * </pre>
     *
     * @param targetCaseId numeric case identifier
     * @return populated root node; never {@code null}
     */
    private TreeNode<Search> buildBusquedaTree(long targetCaseId) {
        TreeNode<Search> root = new DefaultTreeNode<>("root", null, null);

        if (targetCaseId <= 0) {
            return root;
        }

        List<Search> busquedas = caseService.findBusquedasByCaseId(targetCaseId);

        if (busquedas.isEmpty()) {
            log.debug("No search records found for caseId={}", targetCaseId);
            return root;
        }

        // id → TreeNode map for single-pass child attachment
        Map<Long, TreeNode<Search>> nodeMap = new HashMap<>();

        for (Search b : busquedas) {
            TreeNode<Search> node = new DefaultTreeNode<>("search", b, null);
            node.setExpanded(true);

            if (b.isInitial()) {
                // nivel-1: attach directly to root
                node.setParent(root);
                root.getChildren().add(node);
            } else {
                Long parentId = b.getParentBusquedaId();
                TreeNode<Search> parentNode = nodeMap.get(parentId);
                if (parentNode != null) {
                    node.setParent(parentNode);
                    parentNode.getChildren().add(node);
                } else {

                    log.warn("Parent node {} not found for busquedaId={} — attaching to root",
                            parentId, b.getId());
                    node.setParent(root);
                    root.getChildren().add(node);
                }
            }

            nodeMap.put(b.getId(), node);
        }

        log.debug("busquedaTree built: {} nodes for caseId={}", busquedas.size(), targetCaseId);
        return root;
    }

    public void saveFormVersion() {
        if (!validateFormBlocks()) return;

        String json = generarJsonDesdeFormulario();
        if (json == null) return;

        long userId = resolveUserId();
        long id = caseService.saveFormVersion(json, "SHERLOCK", (int) userId, caseId);

        if (id > 0) {

            loadCaseDetail();

            loadFormState();

            editingSherlock = false;
            caseSaved = false;

            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Éxito",
                            "Formulario guardado. Versión ID: " + id));
        } else {
            error("No fue posible guardar el formulario.");
        }
    }

    /**
     * Loads a historical version into the dialog (read-only) without affecting the live form.
     * Builds a {@link FormSummary} for structured display and resets any previous diff state.
     */
    public void viewHistoryForm(CaptureForm form) {
        selectedHistoryForm = form;
        historyReportBlocks = deserializeBlocks(form.getJsonForm());
        selectedFormSummary = FormSummaryBuilder.buildFromJson(form.getJsonForm());
        previousFormSummary = null;
        formDiff = Collections.emptyList();
        showingDiff = false;
        PrimeFaces.current().executeScript("PF('dlgHistorial').show()");
    }

    /**
     * Compares the currently selected history form with the version immediately before it.
     * Populates {@link #formDiff} with human-readable change lines and sets
     * {@link #showingDiff} to {@code true} so the XHTML diff panel becomes visible.
     *
     * <p>The form history list is ordered newest-first (guaranteed by the repository),
     * so the "previous" version is the entry at {@code selectedIndex + 1}.
     */
    public void compareWithPreviousVersion() {
        if (selectedHistoryForm == null || selectedFormSummary == null) return;

        int idx = -1;
        for (int i = 0; i < formHistory.size(); i++) {
            if (formHistory.get(i).getId() == selectedHistoryForm.getId()) {
                idx = i;
                break;
            }
        }

        // formHistory is newest-first → previous is at idx+1
        if (idx >= 0 && idx + 1 < formHistory.size()) {
            CaptureForm prev = formHistory.get(idx + 1);
            previousFormSummary = FormSummaryBuilder.buildFromJson(prev.getJsonForm());
            formDiff = FormSummaryBuilder.diff(selectedFormSummary, previousFormSummary);
        } else {
            previousFormSummary = null;
            formDiff = Collections.singletonList("No hay versión anterior disponible para comparar.");
        }

        showingDiff = true;
    }

    private void restoreBlocksFromJson(String json) {
        List<ReportBlock> blocks = deserializeBlocks(json);
        if (!blocks.isEmpty()) {
            reportBlocks = blocks;
        }
    }

    @SuppressWarnings("unchecked")
    private List<ReportBlock> deserializeBlocks(String json) {
        if (json == null || json.isBlank()) return new ArrayList<>();
        try (jakarta.json.bind.Jsonb jsonb = jakarta.json.bind.JsonbBuilder.create()) {
            List<ReportBlock> blocks = jsonb.fromJson(json,
                    new java.util.ArrayList<ReportBlock>() {
                    }.getClass().getGenericSuperclass());
            return blocks != null ? blocks : new ArrayList<>();
        } catch (Exception e) {
            log.error("Failed to deserialize form blocks: {}", e.getMessage());
            return new ArrayList<>();
        }
    }

//    private boolean validateFormBlocks() {
//        for (int i = 0; i < reportBlocks.size(); i++) {
//            ReportBlock b = reportBlocks.get(i);
//            int blockNum = i + 1;
//
//            if (b.getStartDate() == null || b.getEndDate() == null) {
//                error("Bloque " + blockNum + ": Debe especificar Fecha Inicio y Fecha Fin.");
//                return false;
//            }
//            if (b.getStartDate().isAfter(b.getEndDate())) {
//                error("Bloque " + blockNum + ": La Fecha Inicio no puede ser posterior a la Fecha Fin.");
//                return false;
//            }
//
//            List<CriteriaValue> criteria = b.getCriteria();
//            for (int j = 0; j < criteria.size(); j++) {
//                CriteriaValue c = criteria.get(j);
//                int critNum = j + 1;
//                CriteriaType cType = c.getCriteriaType();
//
//                if (cType == null) {
//                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Debe seleccionar un Tipo de Criterio.");
//                    return false;
//                }
//
//                String v = c.getValue() == null ? "" : c.getValue().trim();
//                c.setValue(v);
//
//                if (v.isEmpty()) {
//                    error("Bloque " + blockNum + ", Criterio " + critNum + ": El valor no puede estar vacío.");
//                    return false;
//                }
//
//                if (v.length() < cType.getMinLength() || v.length() > cType.getMaxLength()) {
//                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Mínimo " + cType.getMinLength() + " caracteres.");
//                    return false;
//                }
//
//                if (!cType.isValid(v)) {
//                    error("Bloque " + blockNum + ", Criterio " + critNum + ": Formato inválido para " + cType.name() + ".");
//                    return false;
//                }
//            }
//
//            if ((b.getStandardReportTypes() == null || b.getStandardReportTypes().isEmpty()) &&
//                    (b.getOnDemandReportTypes() == null || b.getOnDemandReportTypes().isEmpty()) &&
//                    (b.getCdrsReportTypes() == null || b.getCdrsReportTypes().isEmpty()) &&
//                    (b.getCdrsRoamingReportTypes() == null || b.getCdrsRoamingReportTypes().isEmpty()) &&
//                    !b.isDeviceHistory() && !b.isSuscriberHistory()) {
//                error("Bloque " + blockNum + ": seleccione al menos un reporte.");
//                return false;
//            }
//        }
//        return true;
//    }

    private String serializeAddendum() {
        try (jakarta.json.bind.Jsonb jsonb = jakarta.json.bind.JsonbBuilder.create()) {
            return jsonb.toJson(requestAddendum);
        } catch (Exception e) {
            log.error("Failed to serialize addendum: {}", e.getMessage());
            error("Error al procesar el formulario. Intente de nuevo.");
            return null;
        }
    }

    private RequestAddendum deserializeAddendum(String json) {
        try (jakarta.json.bind.Jsonb jsonb = jakarta.json.bind.JsonbBuilder.create()) {
            return jsonb.fromJson(json, RequestAddendum.class);
        } catch (Exception e) {
            log.error("Failed to deserialize addendum from JSON: {}", e.getMessage());
            return new RequestAddendum();
        }
    }

    //FORMS

    /**
     * Appends a new report block to the list.
     */
    public void addBlock() {
        reportBlocks.add(new ReportBlock());
    }

    /**
     * Removes a report block at the specified index. Guarantees that at least one block remains.
     *
     * @param index The zero-based index of the block to eliminate.
     */
    public void removeBlock(int index) {
        if (reportBlocks.size() > 1) {
            reportBlocks.remove(index);
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso",
                            "Debe existir al menos un bloque de criterios."));
        }
    }

    /**
     * Attaches an empty criterion to a specific report block.
     *
     * @param block The ReportBlock instance to attach to.
     */
    public void addCriteria(ReportBlock block) {
        block.addCriteria();
    }

    /**
     * Deletes a specific criterion from a report block and cascades updates.
     *
     * @param block The ReportBlock instance holding the criterion.
     * @param index The zero-based index pointing to the CriteriaValue inside the ReportBlock.
     */
    public void removeCriteria(ReportBlock block, int index) {
        block.removeCriteria(index);
        evaluateAutomaticReports(block);
    }

    /**
     * Clears all configurations, reinstating a single clean ReportBlock.
     */
    public void clear() {
        reportBlocks = new ArrayList<>();
        reportBlocks.add(new ReportBlock());
    }


    /**
     * AJAX Listener invoked when the criteria type dropdown choice is modified in the view.
     *
     * @param block     The holding ReportBlock.
     * @param criterion The specific CriteriaValue item being edited.
     */
    public void onCriteriaChange(ReportBlock block, CriteriaValue criterion) {
        CriteriaType newType = criterion.getCriteriaType();
        if (newType != null) {
            boolean incomingDeviceHistory = newType.isAllowDeviceHistory();
            boolean incomingSuscriberHistory = newType.isAllowsSuscriberHistory();

            if (incomingDeviceHistory || incomingSuscriberHistory) {
                boolean hasDeviceHistory = false;
                boolean hasSuscriberHistory = false;

                for (CriteriaValue c : block.getCriteria()) {
                    if (c == criterion) continue;
                    CriteriaType cType = c.getCriteriaType();
                    if (cType != null) {
                        if (cType.isAllowDeviceHistory()) hasDeviceHistory = true;
                        if (cType.isAllowsSuscriberHistory()) hasSuscriberHistory = true;
                    }
                }

                if (incomingDeviceHistory && hasSuscriberHistory) {
                    criterion.setCriteriaType(null);
                    criterion.setValue("");
                    FacesContext.getCurrentInstance().addMessage(null,
                            new FacesMessage(FacesMessage.SEVERITY_WARN, "Restricción",
                                    "No es posible combinar criterios que permiten histórico con criterios que permiten histórico extendido en el mismo bloque."));
                    return;
                }
                if (incomingSuscriberHistory && hasDeviceHistory) {
                    criterion.setCriteriaType(null);
                    criterion.setValue("");
                    FacesContext.getCurrentInstance().addMessage(null,
                            new FacesMessage(FacesMessage.SEVERITY_WARN, "Restricción",
                                    "No es posible combinar criterios que permiten histórico extendido con criterios que permiten histórico en el mismo bloque."));
                    return;
                }
            }
        }
        criterion.setValue("");
    }

    /**
     * Assesses whether the specified block permits automatic reports and clears selections if not.
     *
     * @param block The ReportBlock evaluated.
     */
    private void evaluateAutomaticReports(ReportBlock block) {
        if (!block.isAutomaticEnabled()) {
            //limpiar reportes automaticos.
        }
    }

    /**
     * Serializa el estado completo del formulario (bloques y criterios) a un string JSON.
     *
     * @return El JSON generado con el estado del formulario.
     */
    public String generarJsonDesdeFormulario() {
        try (jakarta.json.bind.Jsonb jsonb = jakarta.json.bind.JsonbBuilder.create()) {
            return jsonb.toJson(this.reportBlocks);
        } catch (Exception e) {
            log.error("Failed to serialize form to JSON: {}", e.getMessage());
            error("Error al serializar el formulario a JSON.");
            return null;
        }
    }

    /**
     * Raises a severe error message inside the JSF context.
     *
     * @param msg The error description to show.
     */
    private void error(String msg) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msg));
    }

    /**
     * Returns the global sequential index of a criterion across all report blocks.
     *
     * @param target The target CriteriaValue being matched.
     * @return The 1-based global index.
     */
    public int getGlobalCriteriaIndex(CriteriaValue target) {
        int index = 1;
        for (ReportBlock block : reportBlocks) {
            for (CriteriaValue c : block.getCriteria()) {
                if (c == target) {
                    return index;
                }
                index++;
            }
        }
        return index;
    }

    public List<CriteriaType> getCriteriaTypes() {
        return Arrays.asList(CriteriaType.values());
    }

    public List<StandardReportType> getStandardReportTypes() {
        return Arrays.asList(StandardReportType.values());
    }

    public List<OnDemandReportType> getOnDemandReportTypes() {
        return Arrays.asList(OnDemandReportType.values());
    }

    public List<CDRsReportType> getCDRsReportTypes() {
        return Arrays.asList(CDRsReportType.values());
    }

    public List<CDRsRoamingReportType> getCDRsRoamingReportType() {
        return Arrays.asList(CDRsRoamingReportType.values());
    }

    public List<CoverageType> getCoverageType() {
        return Arrays.asList(CoverageType.values());
    }

    public List<AllUsageReportType> getAllUsageReportType() {
        return Arrays.asList(AllUsageReportType.values());
    }

    public List<AllUsageDirection> getAllUsageDirections() {
        return Arrays.asList(AllUsageDirection.values());
    }

    public boolean isSelectedFormSummaryEmpty() {
        return selectedFormSummary == null || selectedFormSummary.isEmpty();
    }
}
