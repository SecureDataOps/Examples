package mx.stackcloud.cm.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;


/**
 * Represents a logical block of report configurations including dates, criteria, and selected reports.
 */
public class ReportBlock implements Serializable {

    @Setter
    @Getter
    private String uuid;

    @Setter
    @Getter
    private List<CriteriaValue> criteria;

    @Setter
    @Getter
    private LocalDateTime startDate;

    @Setter
    @Getter
    private LocalDateTime endDate;

    @Setter
    @Getter
    private Set<StandardReportType> standardReportTypes;

    @Setter
    @Getter
    private Set<OnDemandReportType> onDemandReportTypes;

    @Setter
    @Getter
    private Set<CDRsReportType> cdrsReportTypes;

    @Setter
    @Getter
    private Set<CDRsRoamingReportType> cdrsRoamingReportTypes;

    @Setter
    @Getter
    private Set<CoverageType> coverageTypes;

    @Setter
    @Getter
    private Set<AllUsageReportType> allUsageReportTypes;

    @Setter
    @Getter
    private AllUsageDirection allUsageDirection;

    @Setter
    @Getter
    private boolean deviceHistory;

    @Setter
    @Getter
    private boolean suscriberHistory;

    @Serial
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor initializing default state and dates.
     */
    public ReportBlock() {
        this.uuid = UUID.randomUUID().toString();
        this.criteria = new ArrayList<>();
        this.criteria.add(new CriteriaValue());
        this.startDate = LocalDateTime.now(ZoneId.of("America/Mexico_City"));
        this.endDate = LocalDateTime.now(ZoneId.of("America/Mexico_City"));
        this.standardReportTypes = new HashSet<>();
        this.onDemandReportTypes = new HashSet<>();
        this.cdrsReportTypes = new HashSet<>();
        this.cdrsRoamingReportTypes = new HashSet<>();
        this.coverageTypes = new HashSet<>();
        this.allUsageReportTypes = new HashSet<>();
        this.allUsageDirection = AllUsageDirection.ALL;

        this.deviceHistory = false;
        this.suscriberHistory = false;
    }

    /**
     * Adds an empty criteria to this report block.
     */
    public void addCriteria() {
        this.criteria.add(new CriteriaValue());
    }

    /**
     * Removes the criteria at the specified index. Prevents removing the last remaining criteria.
     *
     * @param index The zero-based index of the criteria to remove.
     */
    public void removeCriteria(int index) {
        if (this.criteria.size() > 1) {
            this.criteria.remove(index);
        }
    }

    /**
     * Checks if automatic reports are allowed for this block, based on the selected criteria types.
     *
     * @return True if at least one criteria supports automatic reports.
     */
    public boolean isAutomaticEnabled() {
        if (criteria == null) return false;
        for (CriteriaValue c : criteria) {
            if (c.getCriteriaType() != null && c.getCriteriaType().isAllowsAutomatic()) {
                return true;
            }
        }
        return false;
    }

    public boolean isDeviceHistoryEnabled() {
        if (criteria == null)
            return false;
        for (CriteriaValue c : criteria) {
            if (c.getCriteriaType() != null && c.getCriteriaType().isAllowDeviceHistory()) {
                return true;
            }
        }
        return false;
    }

    public boolean isSuscriberHistoryEnabled() {
        if (criteria == null)
            return false;
        for (CriteriaValue c : criteria) {
            if (c.getCriteriaType() != null && c.getCriteriaType().isAllowsSuscriberHistory()) {
                return true;
            }
        }
        return false;
    }

}
