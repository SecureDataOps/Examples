package mx.stackcloud.cm.common.exception;

import mx.stackcloud.cm.model.Status;

/**
 * Excepción de negocio que indica una transición de estado no permitida.
 *
 * Se lanza cuando la máquina de estados rechaza el cambio solicitado.
 */
public class InvalidStatusTransitionException extends RuntimeException {

    /**
     * Crea la excepción con los estados involucrados.
     *
     * @param from estado actual
     * @param to   estado destino solicitado
     */
    public InvalidStatusTransitionException(Status from, Status to) {
        super("Transicion invalida: " + from.name() + " (" + from.getId() + ")"
                + " -> " + to.name() + " (" + to.getId() + ")");
    }
}
