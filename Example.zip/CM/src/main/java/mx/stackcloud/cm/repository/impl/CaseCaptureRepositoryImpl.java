package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.model.CaptureForm;
import mx.stackcloud.cm.repository.CaseCaptureRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Named
@ApplicationScoped
public class CaseCaptureRepositoryImpl implements CaseCaptureRepository {

    private static final Logger log = LoggerFactory.getLogger(CaseCaptureRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_DEACTIVATE = """
            UPDATE APPS.DEV_FORM_CAPTURA_HISTORICO
            SET activo = 0
            WHERE id_Caso = ? AND activo = 1
            """;

    private static final String SQL_INSERT_VERSION = """
            INSERT INTO APPS.DEV_FORM_CAPTURA_HISTORICO
                (id_Caso, json_captura, TIPO_FORMULARIO, id_Usuario, activo)
            VALUES (?, ?, ?, ?, 1)
            """;

    private static final String SQL_FIND_ACTIVE = """
            SELECT id, id_caso, json_captura, TIPO_FORMULARIO, id_Usuario, activo, FECHA_REGISTRO
                        FROM APPS.DEV_FORM_CAPTURA_HISTORICO
                        WHERE id_caso = ? AND activo = 1
                        FETCH FIRST 1 ROWS ONLY
            """;

    private static final String SQL_FIND_ALL = """
            SELECT id, id_Caso, json_captura, TIPO_FORMULARIO, id_Usuario, activo, FECHA_REGISTRO
                        FROM APPS.DEV_FORM_CAPTURA_HISTORICO
                        WHERE id_Caso = ?
                        ORDER BY FECHA_REGISTRO DESC NULLS LAST
            """;

    private static final String SQL_HAS_ACTIVE_FORM = """
            SELECT COUNT(1)
            FROM   APPS.DEV_FORM_CAPTURA_HISTORICO
            WHERE  id_Caso = ?
              AND  activo = 1
            """;

    @Override
    public long saveVersionedForm(String jsonForm, String tipoFormulario, int userId, int caseId) {
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            conn.setAutoCommit(false);

            try (PreparedStatement deactivate = conn.prepareStatement(SQL_DEACTIVATE)) {
                deactivate.setInt(1, caseId);
                deactivate.executeUpdate();
            }

            long generatedId = -1;
            try (PreparedStatement insert = conn.prepareStatement(SQL_INSERT_VERSION, new String[]{"ID"})) {
                insert.setInt(1, caseId);
                insert.setString(2, jsonForm);
                insert.setString(3, tipoFormulario);
                insert.setInt(4, userId);
                insert.executeUpdate();

                try (ResultSet keys = insert.getGeneratedKeys()) {
                    if (keys.next()) {
                        generatedId = keys.getLong(1);
                    }
                }
            }

            conn.commit();
            log.info("Saved form version id={} for caseId={} tipo={}", generatedId, caseId, tipoFormulario);
            return generatedId;

        } catch (SQLException e) {
            log.error("saveVersionedForm failed for caseId={}: {}", caseId, e.getMessage());
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    log.error("Rollback failed: {}", ex.getMessage());
                }
            }
            return -1;
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    log.error("Connection close failed: {}", ex.getMessage());
                }
            }
        }
    }

    @Override
    public Optional<CaptureForm> findActiveForm(int caseId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_ACTIVE)) {
            stmt.setInt(1, caseId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            log.error("findActiveForm failed for caseId={}: {}", caseId, e.getMessage());
        }
        return Optional.empty();
    }

    @Override
    public List<CaptureForm> findAllByCaseId(int caseId) {
        List<CaptureForm> result = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_ALL)) {
            stmt.setInt(1, caseId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    result.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            log.error("findAllByCaseId failed for caseId={}: {}", caseId, e.getMessage());
        }
        return result;
    }

    @Override
    public boolean hasActiveForm(long caseId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_HAS_ACTIVE_FORM)) {

            stmt.setLong(1, caseId);

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            log.error("hasActiveForm failed for caseId={}", caseId, e);

            throw new RuntimeException(
                    "Error checking active form for caseId=" + caseId,
                    e
            );
        }
    }

    private CaptureForm mapRow(ResultSet rs) throws SQLException {
        CaptureForm form = new CaptureForm();
        form.setId(rs.getLong("id"));
        form.setCaseId(rs.getInt("id_caso"));
        form.setJsonForm(rs.getString("json_captura"));
        form.setTipoFormulario(rs.getString("TIPO_FORMULARIO"));
        form.setUserId(rs.getInt("id_usuario"));
        form.setActivo(rs.getInt("activo"));
        LocalDateTime fechaHora = rs.getObject("FECHA_REGISTRO", LocalDateTime.class);
        if (fechaHora != null) {
            form.setFechaRegistro(fechaHora);
        }
        return form;
    }
}
