package mx.stackcloud.cm.model;

/**
 * Define los eventos de dominio que provocan cambios de estado en el caso.
 *
 * El estado nunca cambia por navegación ni acción directa de UI.
 * Cada transición ocurre exclusivamente como consecuencia de un evento.
 */
public enum CaseEvent {

    /**
     * El usuario abrió la vista de detalle del caso.
     * Transición esperada: NEW → READ (solo una vez, idempotente).
     */
    OPEN_CASE_VIEW,

    /**
     * El usuario guardó el formulario de captura por primera vez.
     * Transición esperada: READ → CAPTURE.
     */
    SAVE_FIRST_FORM,

    /**
     * El usuario confirmó "Guardar Caso".
     * Transición esperada: CAPTURE → SEARCHING.
     */
    SAVE_CASE,

    /**
     * El usuario canceló el caso.
     * Transición esperada: cualquier estado no terminal → CANCELED.
     */
    CANCEL_CASE,

    /**
     * El usuario marcó el caso como pendiente.
     * Transición esperada: cualquier estado no terminal → PENDING.
     */
    MARK_PENDING,

    /**
     * El usuario reanudó el caso desde estado pendiente.
     * Transición esperada: PENDING → estado anterior (obtenido desde CM_BITACORA).
     */
    RESUME_FROM_PENDING,

    /**
     * El usuario confirmó "Tareas Completadas".
     * Transición esperada: IN_PROGRESS → READY.
     * Requiere que el checklist esté completo: automáticos validados por middleware y manuales seleccionados.
     */
    READY_CASE
}
