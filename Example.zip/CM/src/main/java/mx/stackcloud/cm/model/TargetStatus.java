package mx.stackcloud.cm.model;

/**
 * Estado de resultado reportado por el middleware para un target específico.
 * Proviene del campo "status" dentro de cada objeto en responded_records[].
 *
 * Valores reales del RESPONSE JSON (EVENT_DESCRIPTION donde EVENT = COMPLETE):
 *   RESULTS_AVAILABLE    → el target tiene datos
 *   NO_RESULTS_AVAILABLE → consulta válida sin resultados
 *   ERROR                → fallo en la ejecución del target
 */
public enum TargetStatus {
    RESULTS_AVAILABLE,
    NO_RESULTS_AVAILABLE,
    ERROR;

    /**
     * Convierte el string del payload middleware al enum correspondiente.
     * Cualquier valor no reconocido o null se trata como ERROR.
     */
    public static TargetStatus fromString(String value) {
        if (value == null) return ERROR;
        return switch (value.trim().toUpperCase()) {
            case "RESULTS_AVAILABLE"     -> RESULTS_AVAILABLE;
            case "NO_RESULTS_AVAILABLE"  -> NO_RESULTS_AVAILABLE;
            default                      -> ERROR;
        };
    }

    /**
     * Verifica si el string corresponde a un valor de enum conocido.
     * Úsalo antes de {@link #fromString(String)} cuando un status desconocido
     * debe ser un fallo estructural en lugar de silenciosamente mapearse a ERROR.
     */
    public static boolean isKnown(String value) {
        if (value == null) return false;
        return switch (value.trim().toUpperCase()) {
            case "RESULTS_AVAILABLE", "NO_RESULTS_AVAILABLE", "ERROR" -> true;
            default -> false;
        };
    }

    /** Retorna true si el resultado es aceptable para continuar la transición. */
    public boolean isAcceptable() {
        return this == RESULTS_AVAILABLE || this == NO_RESULTS_AVAILABLE;
    }
}
