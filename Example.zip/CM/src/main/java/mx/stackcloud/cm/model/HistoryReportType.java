package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum HistoryReportType {
    DEVICE("Historico de Dispositivo"),
    SUSCRIBER("Historico de Suscriptor");

    private final String label;

    HistoryReportType(String label) {
        this.label = label;
    }

}
