package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.model.CaseAttachment;
import mx.stackcloud.cm.model.CaseDetail;
import mx.stackcloud.cm.repository.CaseDetailRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Named
@ApplicationScoped
public class CaseDetailRepositoryImpl implements CaseDetailRepository {

    private static final Logger log = LoggerFactory.getLogger(CaseDetailRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_FIND_BY_ID = """
            SELECT casos.ID_CASO, token.ID_TOKEN, casos.FECHA_ESTATUS, casos.FECHA_REGISTRO, casos.ID_ESTATUS AS id_status_case, sol.ID_ESTATUS AS id_status_request, casos.ID_TIPO AS case_type, cp.PRIORIDAD AS priority, ce.SUBJECT, ce.FROMADDRESS, ce.EMAILBODY FROM DEV_CASOS casos
                                    LEFT JOIN DEV_SOLICITUDES sol
                                    ON casos.ID_SOLICITUD = sol.ID_SOLICITUD
                                    LEFT JOIN DEV_TOKEN token
                                    ON sol.ID_TOKEN = token.ID_TOKEN
                                    LEFT JOIN DEV_RECEPCION_EMAIL ce
                                    ON token.ID_EMAIL = ce.ID
                                    LEFT JOIN CATALOGO_PRIORIDADES cp
                                    ON sol.ID_PRIORIDAD = cp.ID
                                    WHERE casos.ID_CASO = ?          
            """;

    private static final String SQL_FIND_ATTACHMENTS = """
            SELECT addj.* FROM DEV_RECEPCION_ADJUNTOS addj
                                    LEFT JOIN DEV_TOKEN token
                                    ON token.ID_EMAIL = addj.ID_EMAIL
                                    LEFT JOIN DEV_SOLICITUDES sol
                                    ON sol.ID_TOKEN  = token.ID_TOKEN
                                    LEFT JOIN DEV_CASOS casos
                                    ON casos.ID_SOLICITUD = sol.ID_SOLICITUD
                                    WHERE casos.ID_CASO = ?
                        ORDER BY addj.id ASC
            """;

    @Override
    public Optional<CaseDetail> findById(int caseId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND_BY_ID)) {

            stmt.setInt(1, caseId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {

                    CaseDetail detail = mapRow(rs);

                    detail.setAttachments(findAttachments(conn, caseId));
                    return Optional.of(detail);
                }
            }

        } catch (SQLException e) {
            log.error("findById failed for caseId={}: {}", caseId, e.getMessage());
        }

        return Optional.empty();
    }

    private List<CaseAttachment> findAttachments(Connection conn, int caseId) throws SQLException {

        List<CaseAttachment> attachments = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(SQL_FIND_ATTACHMENTS)) {
            stmt.setInt(1, caseId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    CaseAttachment att = new CaseAttachment();
                    att.setId(rs.getInt("id"));
                    att.setEmailId(rs.getInt("id_email"));
                    att.setFilename(rs.getString("filename"));
                    att.setPath(rs.getString("path"));

                    Timestamp fechaReg = rs.getTimestamp("FECHA_REGISTRO");
                    if (fechaReg != null) {
                        att.setRegistrationDate(fechaReg.toLocalDateTime());
                    }

                    attachments.add(att);
                }
            }
        }

        return attachments;
    }

    private CaseDetail mapRow(ResultSet rs) throws SQLException {
        //System.out.println("MapRow caseDetail");
        CaseDetail detail = new CaseDetail();
        detail.setId(rs.getInt("ID_CASO"));
        detail.setToken(rs.getString("ID_TOKEN"));
        detail.setIdStatusCase(rs.getInt("ID_STATUS_CASE"));
        detail.setIdStatusRequest(rs.getInt("ID_STATUS_REQUEST"));
        detail.setRequestType(rs.getString("CASE_TYPE"));
        detail.setPriority(rs.getString("PRIORITY"));

        Timestamp statusDate = rs.getTimestamp("FECHA_ESTATUS");
        if (statusDate != null) {
            detail.setStatusDate(statusDate.toLocalDateTime());
        }

        Timestamp registrationDate = rs.getTimestamp("FECHA_REGISTRO");
        if (registrationDate != null) {
            detail.setRegistrationDate(registrationDate.toLocalDateTime());
        }

        detail.setEmailSubject(rs.getString("SUBJECT"));
        detail.setEmailFrom(rs.getString("FROMADDRESS"));
        detail.setEmailBody(rs.getString("EMAILBODY"));

        return detail;
    }
}
