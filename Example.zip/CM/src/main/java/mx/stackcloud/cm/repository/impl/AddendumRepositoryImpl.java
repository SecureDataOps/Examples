package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.repository.AddendumRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.StringReader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

@Named
@ApplicationScoped
public class AddendumRepositoryImpl implements AddendumRepository {

    private static final Logger log = LoggerFactory.getLogger(AddendumRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_FIND = """
            SELECT compl.json_complemento
                        FROM APPS.DEV_COMPLEMENTO compl
                        LEFT JOIN APPS.DEV_SOLICITUDES sol
                        ON compl.id_solicitud = sol.id_solicitud
                        WHERE sol.ID_TOKEN  = ?
            """;

    private static final String SQL_INSERT = """
            INSERT INTO APPS.DEV_COMPLEMENTO (id_solicitud, json_complemento, ID_USUARIO)
                        VALUES ((SELECT id_solicitud FROM APPS.DEV_SOLICITUDES WHERE id_token=?), ?, ?)
            """;

    private static final String SQL_UPDATE = """
            UPDATE APPS.DEV_COMPLEMENTO
                        SET json_complemento = ?,
                            ID_USUARIO   = ?
                        WHERE ID_SOLICITUD  = (SELECT id_solicitud FROM APPS.DEV_SOLICITUDES WHERE id_token=?)
            """;

    @Override
    public Optional<String> findByFolio(String ID_TOKEN) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_FIND)) {

            stmt.setString(1, ID_TOKEN);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String json = readClob(rs, 1);
                    return Optional.ofNullable(json);
                }
            }

        } catch (SQLException e) {
            log.error("findByFolio failed for ID_TOKEN={}: {}", ID_TOKEN, e.getMessage());
        }

        return Optional.empty();
    }

    @Override
    public boolean save(String ID_TOKEN, String json, int userId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT)) {

            stmt.setString(1, ID_TOKEN);
            stmt.setCharacterStream(2, new StringReader(json), json.length());
            stmt.setInt(3, userId);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            log.error("save complemento failed for ID_TOKEN={}: {}", ID_TOKEN, e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(String ID_TOKEN, String json, int userId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {

            stmt.setCharacterStream(1, new StringReader(json), json.length());
            stmt.setInt(2, userId);
            stmt.setString(3, ID_TOKEN);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            log.error("update complemento failed for ID_TOKEN={}: {}", ID_TOKEN, e.getMessage());
            return false;
        }
    }

    private String readClob(ResultSet rs, int columnIndex) throws SQLException {
        Clob clob = rs.getClob(columnIndex);
        if (clob == null) return null;
        return clob.getSubString(1, (int) clob.length());
    }
}
