package mx.stackcloud.cm.repository.impl;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import mx.stackcloud.cm.model.MiddlewareJob;
import mx.stackcloud.cm.repository.MiddlewareRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.Reader;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * Implementación JDBC del repositorio de middleware.
 * Consulta DEV_MIDDLEWARE_JOB y DEV_MIDDLEWARE_JOB_EVENT en modo solo lectura.
 */
@Named
@ApplicationScoped
public class MiddlewareRepositoryImpl implements MiddlewareRepository {

    private static final Logger log = LoggerFactory.getLogger(MiddlewareRepositoryImpl.class);

    @Resource(lookup = "java:/EnlaceDS")
    private DataSource dataSource;

    private static final String SQL_LATEST_JOB = """
            SELECT MJ_ID, JOB_ID, CASE_ID, PRIORITY, STATUS, CREATED_ON, UPDATE_ON
            FROM APPS.DEV_MIDDLEWARE_JOB
            WHERE CASE_ID = ?
            ORDER BY CREATED_ON DESC
            FETCH FIRST 1 ROW ONLY
            """;

    private static final String SQL_LATEST_EVENT = """
            SELECT EVENT
            FROM APPS.DEV_MIDDLEWARE_JOB_EVENT
            WHERE JOB_ID = ?
            ORDER BY CREATED_ON DESC
            FETCH FIRST 1 ROW ONLY
            """;

    private static final String SQL_COMPLETE_EVENT_DESC = """
            SELECT EVENT_DESCRIPTION
            FROM APPS.DEV_MIDDLEWARE_JOB_EVENT
            WHERE JOB_ID = ?
              AND EVENT = 'COMPLETE'
            ORDER BY CREATED_ON DESC
            FETCH FIRST 1 ROW ONLY
            """;

    @Override
    public Optional<MiddlewareJob> findLatestJobByCaseId(long caseId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_LATEST_JOB)) {

            ps.setLong(1, caseId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(MiddlewareJob.builder()
                            .mjId(rs.getLong("MJ_ID"))
                            .jobId(rs.getLong("JOB_ID"))
                            .caseId(rs.getLong("CASE_ID"))
                            .priority(rs.getString("PRIORITY"))
                            .status(rs.getString("STATUS"))
                            .createdOn(rs.getTimestamp("CREATED_ON") != null
                                    ? rs.getTimestamp("CREATED_ON").toLocalDateTime() : null)
                            .updateOn(rs.getTimestamp("UPDATE_ON") != null
                                    ? rs.getTimestamp("UPDATE_ON").toLocalDateTime() : null)
                            .build());
                }
            }

        } catch (SQLException e) {
            log.error("Error buscando job en middleware para caseId={}", caseId, e);
        }

        return Optional.empty();
    }

    @Override
    public Optional<String> findLatestEventByJobId(long jobId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_LATEST_EVENT)) {

            ps.setLong(1, jobId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.ofNullable(rs.getString("EVENT"));
                }
            }

        } catch (SQLException e) {
            log.error("Error buscando último evento para jobId={}", jobId, e);
        }

        return Optional.empty();
    }

    @Override
    public Optional<String> findCompleteEventDescriptionByJobId(long jobId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_COMPLETE_EVENT_DESC)) {

            ps.setLong(1, jobId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Clob clob = rs.getClob("EVENT_DESCRIPTION");
                    if (clob != null) {
                        return Optional.of(readClob(clob));
                    }
                }
            }

        } catch (SQLException e) {
            log.error("Error buscando EVENT_DESCRIPTION del evento COMPLETE para jobId={}", jobId, e);
        }

        return Optional.empty();
    }

    private String readClob(Clob clob) throws SQLException {
        StringBuilder sb = new StringBuilder();
        try (Reader reader = clob.getCharacterStream()) {
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, read);
            }
        } catch (IOException e) {
            throw new SQLException("Error leyendo CLOB de EVENT_DESCRIPTION", e);
        }
        return sb.toString();
    }
}
