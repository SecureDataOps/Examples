package mx.stackcloud.cm.model;

import lombok.Getter;

@Getter
public enum AllUsageDirection {
    ALL("All"),
    INCOMING("Incoming"),
    OUTGOING("Outgoing");

    private final String label;

    AllUsageDirection(String label) {
        this.label = label;
    }
}
